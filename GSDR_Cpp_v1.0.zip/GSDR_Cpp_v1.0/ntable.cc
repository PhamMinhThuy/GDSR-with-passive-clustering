#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <random.h>
#include <agent.h>
#include <packet.h>
#include <scheduler.h>
#include <classifier-port.h>
#include <address.h>
#include "ntable.h"
#include "gdsragent.h"

#include "common/scheduler.h"
#include "common/ip.h"
#include "common/agent.h"
#include "queue/dsr-priqueue.h"

int GDSR_Agent::no_of_clusters_;

static inline double jitter (double max, int be_random_)
{
    return (be_random_ ? Random::uniform(max) : 0);
}

GDSRNeighborTableTimeoutHandler::GDSRNeighborTableTimeoutHandler(GDSR_Agent *a_,
        GDSRNeighborTable *t_)
{
    a = a_;
    t = t_;
}

GDSRNeighborTableContentionHandler::GDSRNeighborTableContentionHandler(GDSR_Agent *a_,
        GDSRNeighborTable *t_)
{
    a = a_;
    t = t_;
}


GDSRNeighborTablePeriodicHandler::GDSRNeighborTablePeriodicHandler(GDSR_Agent *a_, GDSRNeighborTable *t_)
{
    a = a_;
    t = t_;
}

Packet *GDSRNeighborTable::sendGiveUpPacket()
{
    printf("In sendgiveUpPacket\n");
    //double b_time = 1.1 * GDSR_BROADCAST_INTERVAL;
    Packet *p = a->allocpkt();
    hdr_ip *iph = HDR_IP(p);
    hdr_cmn *hdrc = HDR_CMN(p);

   // ntable_ent *prte;

    hdrc->ptype() = PT_MESSAGE;
    hdrc->direction() = hdr_cmn::DOWN;
    hdrc->next_hop() = MAC_BROADCAST;
    hdrc->addr_type() = NS_AF_INET;

    iph->daddr() = IP_BROADCAST;
    iph->dport() =  RT_PORT;
    iph->saddr() = a->net_id.addr;
    iph->sport() = RT_PORT;

   // iph->giveup() = TRUE;
    iph->node_id() = a->net_id.addr;
    iph->state() = my_status;
    iph->clusterhead[0] =  my_label;
    if (adjtable_size2 <= 5)
    {
        iph->num_adj_clusters() = adjtable_size2;
    }
    else
    {
        iph->num_adj_clusters() = 5;
    }

    //add
    
     adjtable_ent *e = adjtable_2;
          for (int i = 1; i <= adjtable_size2; i++)
          {
              if(i <= 5)
              {
                  while(e)
                  {
                      iph->clusterhead[i] = e->neighbor_cluster;
                      e = e->next;
                      break;
                  }
              }
              else
              {
                  break;
              }
          }



    hdrc->size_ = 32;

    return p;

}

void GDSRNeighborTablePeriodicHandler::handle(Event *event)
{
   printf("In GDSRNeighborTablePeriodicHandler of node %i, my_status = %i, my_label =  %i\n",a->net_id.addr,t->my_status, t->my_label);
 Scheduler &s = Scheduler::instance();
    if(t->my_status != CLUSTER_HEAD)
   {
        if(t->periodic_event) s.cancel(t->periodic_event);
        s.schedule(this, event, GDSR_BROADCAST_INTERVAL *(0.75 + jitter(0.25, a->be_random_)));
        return;
   }
    else
    {


        if(!t->periodic_event)
        {
    Packet *p;
   
    p = t->sendGiveUpPacket();
    s.schedule(a->ll, p, jitter(GDSR_BROADCAST_JITTER,a->be_random_));
    s.schedule(this, event, GDSR_BROADCAST_INTERVAL *(0.75 + jitter(0.25, a->be_random_)));
        }
    }
        
   
    
    
}


GDSRNeighborTable::GDSRNeighborTable(GDSR_Agent* a_)
{
    head = NULL;
    adjtable_1 = NULL;
    adjtable_2 = NULL;
    

    no_of_clusterheads = 0;
    no_of_initials = 0;
    no_of_gateways = 0;
    no_of_ordinaries = 0;

    adjtable_size1 = 0;
    adjtable_size2 = 0;

    last_size1 = 0;


   // internal_status = INITIAL_NODE;
    external_status = INITIAL_NODE;
    last_status = INITIAL_NODE;
    my_status = 1;


    my_label = 255;
    my_rival = 255;
    last_label = 255;

    a = a_;
    in_contention = 0;

    c_contention_event = new Event();
    periodic_event = new Event();
    timeout_handler = new GDSRNeighborTableTimeoutHandler(a, this);
    c_contention_handler = new GDSRNeighborTableContentionHandler(a, this);
    periodic_handler = new GDSRNeighborTablePeriodicHandler(a,this);

}

void GDSRNeighborTable::InitLoop()
{
    prev = NULL;
    now = NULL;
}

ntable_ent *GDSRNeighborTable::NextLoop()
{
    prev = now;
    if (!now)
    {
        now = head;
    }
    else
    {
        now = now->next;
    }
    return now;
}




void GDSRNeighborTableTimeoutHandler ::handle(Event* event)
{
    //printf("\n In GDSRNeighborTableTimeoutHandler\n");
    ntable_ent *prte;
    int deleted = 0;

    //check out the entry that cuased this timeout event
    for (t->InitLoop(); (prte = t->NextLoop());)
    {
        if (prte->timeout_event == event)
        {
      //      printf("Node %i is timeout\n", prte->neighbor);
            prte->timeout_event = NULL;
            t->DeleteEntry(prte->neighbor);
            if (t->GetAdjEntry(prte->neighbor, 1)) t->DeleteNeighborCluster(prte->neighbor, 1);
            if (t->GetAdjEntry(prte->neighbor,0)) t->DeleteNeighborCluster(prte->neighbor, 0);
            delete event;
            deleted++;
            if (deleted > 1)
            {
                printf("duplicated! \n;");
            }
        }
    }



    if (deleted)
    {
        return;
    }

    if ((checkAdjTimeout(event, 1)) || (checkAdjTimeout(event,0)))
    {
        delete event;
        return;
    }
}


int GDSRNeighborTableTimeoutHandler::checkAdjTimeout(Event* event, int primary)
{
    adjtable_ent *p;
    adjtable_ent *p_prev = NULL;
    nexthop_ent *hop = NULL;
    nexthop_ent *hop_prev = NULL;

    if (primary)
    {
        p = t->adjtable_1;
    }
    else
    {
        p = t->adjtable_2;
    }

    while(p)
    {
        hop = p->next_hop;
        hop_prev = NULL;
        while(hop)
        {
            if(hop->timeout_event == event)
            {
                if(hop_prev)
                {
                    hop_prev->next = hop->next;
                }
                else
                {
                    p->next_hop = hop->next;
                }

                if(!p->next_hop)
                {
                    if(p_prev)
                    {
                        p_prev->next = p->next;
                        delete p;
                    }
                    else
                    {
                        if(primary) {
                            t->adjtable_1 = p->next;
                        }
                        else
                        {
                            t->adjtable_2 = p->next;
                        }
                        delete p;
                    }
                    if (primary)
                    {
                        t->adjtable_size1--;

                    }
                    else
                    {
                        t->adjtable_size2--;
                    }
                }

                hop->timeout_event = NULL;
        delete hop;
                return 1;

            }
            hop_prev = hop;
            hop = hop->next;
        }
        p_prev = p;
        p = p->next;
    }
    return 0;
}




void GDSRNeighborTableContentionHandler::handle(Event * event)
{
   // if (t->external_status != CLUSTER_HEAD)
    if (t->my_status != CLUSTER_HEAD)
    {
        t->in_contention = 0;
        return;
    }

    ntable_ent *ent;
    ent = t->head;

   // Packet *p;

   // Scheduler &s = Scheduler::instance();

    while (ent)
    {

             if ((uint)a->net_id.addr > ent->neighbor)
            {
                //resigned the position as GDSR head

               // t->internal_status= GW_READY;
                 t->my_status = GW_READY;
                GDSR_Agent::no_of_clusters_--;
                printf("Now, no_of_clusters_ = %i\n", GDSR_Agent::no_of_clusters_);
                //in cbrp there no break when CLUSTER_HEAD changes to CLUSTER_MEMBER, but i think we must add break here
                //to avoid loop between clusterhead and othr neighbor clusterheads->false no_of_clusters
                break;
            }

        ent = ent->next;
    }

    t->in_contention = 0;

}

void GDSRNeighborTable::processUpdate(Packet *p)
{

    hdr_ip *iph = HDR_IP(p);
    hdr_cmn *cmnh = HDR_CMN(p);
    

    Scheduler &s = Scheduler::instance();
    ntable_ent *rte = new ntable_ent();
    rte->last_update = s.clock();
    rte->neighbor = iph->node_id();
    rte->neighbor_status = iph->state();
    rte->neighbor_label = iph->clusterhead[0];
    rte->next = NULL;


      if (my_status == INITIAL_NODE )
    {
        if (iph->state() != CLUSTER_HEAD)
        {
        my_status = CLUSTER_HEAD;
        my_label = a->net_id.getNSAddr_t();


        }
        else
        {
            last_status = INITIAL_NODE;
        my_status = ORDINARY_NODE;
        my_label = iph->node_id();
        }
    }

    if(my_status == CLUSTER_HEAD && rte->neighbor_status == CLUSTER_HEAD)
    {
        if (a->net_id.getNSAddr_t() > rte->neighbor)
        {

            last_status = CLUSTER_HEAD;
            last_label = a->net_id.getNSAddr_t();
            my_status = ORDINARY_NODE;
            my_label = rte->neighbor;
        }
        else
        {
            return;
        }
    }



    AddUpdateEntry(rte);
    DeleteAdjEntry(iph->node_id(), 0);
     DeleteAdjEntry(iph->node_id(), 1);
    if(iph->num_adj_clusters())
    {
       //  DeleteAdjEntry(iph->node_id(), 1);
         for (int i = 1; i <= iph->num_adj_clusters(); i++)
        {
             if (iph->clusterhead[i] != 255)
                 AddUpdateAdj(iph->clusterhead[i], iph->node_id(),rte->neighbor_label, 1);
        }

    }
    //adjtable2 : direct neighbor cluster, adjtable1: gateway list
    if (rte->neighbor_label != my_label && rte->neighbor_label != 255)
    {
        AddUpdateAdj(rte->neighbor_label, iph->node_id(),rte->neighbor_label, 1);
        AddUpdateAdj(rte->neighbor_label, iph->node_id(),rte->neighbor_label, 0);
    }



     ntable_ent *pr = head;
    while(pr)
    {
       adjtable_ent *entr = GetAdjEntry(pr->neighbor,1);
    if (entr && pr->neighbor_status != CLUSTER_HEAD)
    {
       
        DeleteNeighborCluster(pr->neighbor, 1);
        
    }
       entr = GetAdjEntry(pr->neighbor, 0);
       if(entr && pr->neighbor_status != CLUSTER_HEAD)
       {
           DeleteNeighborCluster(pr->neighbor,0);
       }
       
       pr = pr->next;
    }

/*
     pr = head;
     while(pr)
     {
         ntable_ent *e = GetEntry(pr->neighbor_label);
         if(e && (e->neighbor_status != CLUSTER_HEAD))
         {
             DeleteEntry(pr->neighbor);
         }
         pr = pr->next;
     }
*/

   // if (my_status != CLUSTER_HEAD) changeMemberState(p);

     if(GetAdjEntry(my_label,1))
          DeleteNeighborCluster(my_label, 1);
     if(GetAdjEntry(a->net_id.addr,1))
         DeleteNeighborCluster(a->net_id.addr,1);

     if(GetAdjEntry(my_label,0))
         DeleteNeighborCluster(my_label,0);
     if(GetAdjEntry(a->net_id.addr,1))
         DeleteNeighborCluster(a->net_id.addr,0);

     if (my_status != CLUSTER_HEAD) changeMemberState(p);

 
    
    printf("State of node %i: my_status = %i, my_label = %i\n", a->net_id.getNSAddr_t(), my_status, my_label);


    printf("List of %i neighbors\n", no_of_clusterheads + no_of_gateways+ no_of_ordinaries + no_of_initials);
    ntable_ent *ent = head;
    while (ent)
    {
        printf("Node %i, status = %i, label = %i\n", ent->neighbor, ent->neighbor_status, ent->neighbor_label);
        ent = ent->next;
    }

    printf("List of %i neighbor clusters \n", adjtable_size1);
    adjtable_ent *temp = adjtable_1;
    nexthop_ent *hop;

    while(temp)
    {
        hop = temp->next_hop;
        printf("Neighbor cluster: %i\n", temp->neighbor_cluster);
        while(hop)
        {
            printf("  next_node = %i, next_node_label  = %i\n", hop->next_node, hop->next_node_label);
            hop = hop->next;
        }
        temp = temp->next;
    }
  


}



void GDSRNeighborTable::AddUpdateEntry(ntable_ent* prte)
{
    printf("In AddUpdateEntry\n");
    ntable_ent *tmp;
    ntable_ent *prev_tmp;

    Scheduler &s = Scheduler::instance();
    //assert((prte->neighbor > 0) && (prte->neighbor <= MAX_NODE_NUM));

    tmp = head;
    prev_tmp = NULL;
    while (tmp && (tmp->neighbor != prte->neighbor))
    {
     
        prev_tmp = tmp;
        tmp = tmp->next;
    }


    //add for rival
    if( tmp && (tmp->neighbor == my_rival) && (tmp->neighbor_status != FULL_GW || tmp->neighbor_status != DIST_GW)
            && (my_status == ORDINARY_NODE) && adjtable_size2)
    {
        my_status = DIST_GW;
    }



    if (tmp)
    {
        prte->timeout_event = tmp->timeout_event;
        s.cancel(tmp->timeout_event);
         if(tmp->neighbor_status == CLUSTER_HEAD)
             {
                 no_of_clusterheads--;
             }
             else if(tmp->neighbor_status == DIST_GW || tmp->neighbor_status == FULL_GW)
             {
                 no_of_gateways--;
             }
             else if(tmp->neighbor_status == ORDINARY_NODE)
             {
                 no_of_ordinaries--;
             }
             else
             {
                 no_of_initials--;
             }

         if (prte->neighbor_status == CLUSTER_HEAD)
           {

             no_of_clusterheads++;
           }
        else if ((prte->neighbor_status == DIST_GW || prte->neighbor_status == FULL_GW))
           {
               no_of_gateways++;
           }
        else if ((prte->neighbor_status == ORDINARY_NODE))
           {
               no_of_ordinaries++;
           }
        else if ((prte->neighbor_status == INITIAL_NODE))
               no_of_initials++;
    }
    else
    {
        if (prte->neighbor_status == CLUSTER_HEAD)
           {
               no_of_clusterheads++;
           }
        else if (prte->neighbor_status == DIST_GW || prte->neighbor_status == FULL_GW)
           {
               no_of_gateways++;
           }
        else if (prte->neighbor_status == ORDINARY_NODE)
           {
               no_of_ordinaries++;
           }
           else
               no_of_initials++;


        prte->timeout_event = new Event;
    }

    //s.schedule(timeout_handler, prte->timeout_event, 2.1 * GDSR_BROADCAST_INTERVAL);
    s.schedule(timeout_handler, prte->timeout_event, GDSR_BROADCAST_INTERVAL);

    if (prev_tmp && tmp)
    {
        prev_tmp->next = prte;
        prte->next = tmp->next;
        tmp->next = NULL;
        delete tmp;
    }
    else if (tmp)
    {
        prte->next = tmp->next;
        head = prte;
        tmp->next = NULL;
        delete tmp;
    }
    else
    {
       
        prte->next = head;
        head = prte;
    }


    printf("no_of_clusterheads = %i\n", no_of_clusterheads);
    //add for cluster
    ntable_ent *e = GetEntry(my_label);
    if(!GetEntry(my_label) || (e->neighbor_status != CLUSTER_HEAD))
           {
              last_label = my_label;
               if(my_status != CLUSTER_HEAD)
               {
               if(!no_of_clusterheads)
               {
                   my_status = INITIAL_NODE;
                   my_label = 255;
                   my_rival = 255;
               }
               else
               {

                   ntable_ent *en = head;
                   while(en)
                   {

                       if(en->neighbor_status == CLUSTER_HEAD)
                       {
                           my_label = en->neighbor;
                          DeleteNeighborCluster(my_label,1);
                          DeleteNeighborCluster(my_label,0);
                           break;
                       }
                       en = en->next;
                   }

              }
            }

           }


   

}






ntable_ent *GDSRNeighborTable::GetEntry(nsaddr_t dest)
{
    ntable_ent *ent;
    ent = head;
    while (ent)
    {
        if (ent->neighbor == dest)
            return ent;
        ent = ent->next;
    }
    return NULL;
}



int GDSRNeighborTable::DeleteEntry(nsaddr_t dest)
{
  //  printf("In DeleteEntry, table = %i, dest = %i\n", table, dest);
    Scheduler &s = Scheduler::instance();
        ntable_ent *tmp;
       ntable_ent *tmp_prev;
     // if (now && (now->neighbor == dest))
     //  {
     //      tmp = now;
     //      tmp_prev = prev;
     //  }
     //  else
    //  {
           tmp = head;
           tmp_prev = NULL;
           while (tmp && (tmp->neighbor != dest))
           {
               tmp_prev = tmp;
               tmp = tmp->next;
           }
     //  }

           //add for rival
           if(tmp && (tmp->neighbor == my_rival) && (my_status == ORDINARY_NODE ) && adjtable_size2)
           {
               my_status = DIST_GW;
           }

       if (tmp)
       {
           if (tmp->neighbor_status == CLUSTER_HEAD) 
           {
               no_of_clusterheads--;
           }
           else if (tmp->neighbor_status == DIST_GW || tmp->neighbor_status == FULL_GW)
           {
               no_of_gateways--;
           }
           else if (tmp->neighbor_status == ORDINARY_NODE)
           {
               no_of_ordinaries--;
           }
           else
               no_of_initials--;

          
          

           
           if (tmp_prev)
           {
               tmp_prev->next = tmp->next;
           }
           else
           {
               head = tmp->next;
           }

           if (tmp->timeout_event)
           {
               s.cancel(tmp->timeout_event);
           }
           tmp->timeout_event = NULL;
           tmp->next = NULL;
           delete tmp;
       }
       else
       {
           return 0;
       }


           if(!GetEntry(my_label))
           {
               last_label = my_label;
               if(my_status != CLUSTER_HEAD)
               {
               if(!no_of_clusterheads)
               {
                   my_status = INITIAL_NODE;
                   my_rival = 255;
               }
               else
               {

                   ntable_ent *en = head;
                   while(en)
                   {
                      
                       if(en->neighbor_status == CLUSTER_HEAD)
                       {
                           my_label = en->neighbor;
                          DeleteNeighborCluster(my_label,1);
                          DeleteNeighborCluster(my_label,0);
                           break;
                       }
                       en = en->next;
                   }

              }
            }

           }
           




       
       return 1;
   

}


void GDSRNeighborTable::AddUpdateAdj(nsaddr_t dest, nsaddr_t next_hop, int primary)
{
    adjtable_ent *tmp;
    adjtable_ent *prev = NULL;
        adjtable_ent *ent;

        nexthop_ent *hop_prev;
        nexthop_ent *hop = NULL;

        Scheduler &s = Scheduler::instance();
        if (primary)
        {
            tmp = adjtable_1;
        }
        else
        {
            tmp = adjtable_2;
        }

        while(tmp && tmp->neighbor_cluster != dest)
        {
            prev = tmp;
            tmp = tmp->next;
        }

        if (tmp)
        {
            hop = tmp->next_hop;
            hop_prev = NULL;
            while(hop)
            {
                if (hop->next_node == next_hop)
                {
                    break;
                }
                hop_prev = hop;
                hop = hop->next;
            }

            if (hop)
            {
                s.cancel(hop->timeout_event);
                s.schedule(timeout_handler, hop->timeout_event, 1.1 * GDSR_BROADCAST_INTERVAL);
            }
            else
            {
                hop =   new nexthop_ent();
                hop->next = NULL;
                hop->next_node = next_hop;
                hop->timeout_event = new Event;
                s.schedule(timeout_handler, hop->timeout_event, 1.1 * GDSR_BROADCAST_INTERVAL);

                if (hop_prev == NULL)
                {
                    hop->next = tmp->next_hop;
                    tmp->next_hop = hop;
                }
                else
                {
                    hop_prev->next = hop;
                }

            }
        }
        else
        {
            ent = new adjtable_ent();
            ent->neighbor_cluster = dest;

            hop = new nexthop_ent();
            hop->next = NULL;
            hop->next_node = next_hop;
            hop->timeout_event = new Event;
            s.schedule(timeout_handler, hop->timeout_event, 1.1 * GDSR_BROADCAST_INTERVAL);
            ent->next_hop = hop;

            if (primary)
            {
                ent->next = adjtable_1;
                adjtable_1 = ent;
                adjtable_size1++;
            }
            else
            {
                ent->next = adjtable_2;
                adjtable_2 = ent;
                adjtable_size2++;
            }
        }

}

void GDSRNeighborTable::AddUpdateAdj(nsaddr_t dest, nsaddr_t next_hop, nsaddr_t label, int primary)
{
    adjtable_ent *tmp;
    adjtable_ent *prev = NULL;
        adjtable_ent *ent;

        nexthop_ent *hop_prev;
        nexthop_ent *hop = NULL;

        Scheduler &s = Scheduler::instance();
        if (primary)
        {
            tmp = adjtable_1;
        }
        else
        {
            tmp = adjtable_2;
        }
        
        while(tmp && tmp->neighbor_cluster != dest)
        {
            prev = tmp;
            tmp = tmp->next;
        }

        if (tmp)
        {
            
            hop = tmp->next_hop;
            hop_prev = NULL;
            while(hop)
            {
                if (hop->next_node == next_hop)
                {
                    break;
                }
                hop_prev = hop;
                hop = hop->next;
            }

            if (hop)
            {
                s.cancel(hop->timeout_event);
               // s.schedule(timeout_handler, hop->timeout_event, 1.1 * GDSR_BROADCAST_INTERVAL);
                 s.schedule(timeout_handler, hop->timeout_event, 0.6 * GDSR_BROADCAST_INTERVAL);
            }
            else
            {
                hop =   new nexthop_ent();
                hop->next = NULL;
                hop->next_node = next_hop;
                hop->next_node_label = label;
                hop->timeout_event = new Event;
               // s.schedule(timeout_handler, hop->timeout_event, 1.1 * GDSR_BROADCAST_INTERVAL);
                s.schedule(timeout_handler, hop->timeout_event, 0.6 * GDSR_BROADCAST_INTERVAL);

                if (hop_prev == NULL)
                {
                    hop->next = tmp->next_hop;
                    tmp->next_hop = hop;
                }
                else
                {
                    hop_prev->next = hop;
                }

            }
        }
        else
        {
            ent = new adjtable_ent();
            ent->neighbor_cluster = dest;


            hop = new nexthop_ent();
            hop->next = NULL;
            hop->next_node = next_hop;
            hop->next_node_label = label;
            hop->timeout_event = new Event;
          //  s.schedule(timeout_handler, hop->timeout_event, 1.1 * GDSR_BROADCAST_INTERVAL);
             s.schedule(timeout_handler, hop->timeout_event, 0.6 * GDSR_BROADCAST_INTERVAL);
            ent->next_hop = hop;

            if (primary)
            {
                ent->next = adjtable_1;
                adjtable_1 = ent;
                adjtable_size1++;
            }
            else
            {
                ent->next = adjtable_2;
                adjtable_2 = ent;
                adjtable_size2++;
            }
        }

}


adjtable_ent *GDSRNeighborTable::GetAdjEntry(nsaddr_t dest_cluster, int primary)
{
    adjtable_ent *ent;
    if(primary)
    {
        ent = adjtable_1;
    }
    else
    {
        ent = adjtable_2;
    }

    while(ent)
    {
        if(ent->neighbor_cluster == dest_cluster) return ent;
        ent = ent->next;
    }
    return NULL;
}

/*
void GDSRNeighborTable::DeleteAdjEntry(nsaddr_t dest, int primary)
{
adjtable_ent *tmp;
adjtable_ent *tmp_prev = NULL;

nexthop_ent *hop = NULL;
nexthop_ent *hop_prev = NULL;

if(primary)
{
tmp = adjtable_1;
}
else
{
tmp = adjtable_2;
}

while(tmp)
{
hop = tmp->next_hop;
hop_prev = NULL;

while(hop )
{

    if(hop->next_node == dest)
    {
        if(hop_prev)
        {
            hop_prev->next = hop->next;

        }
        else
        {
            tmp->next_hop = hop->next;
        }


if(!tmp->next_hop)
{
    if (tmp_prev)
    {
        tmp_prev->next = tmp->next;
        delete tmp;
    }
    else
    {
        if(primary)
        {
            adjtable_1 = tmp->next;
        }
        else
        {
           adjtable_2 = tmp->next;
        }
        delete tmp;
    }

    if(primary)
    {
        adjtable_size1--;
    }
    else
    {
        adjtable_size2--;
    }

}
    delete hop;
    return;
    }
    hop_prev = hop;
    hop = hop->next;
}
tmp_prev = tmp;
tmp = tmp->next;
}




}
*/
void GDSRNeighborTable::DeleteNeighborCluster(nsaddr_t dest, int primary)
{

  printf("In DeleteNeighborCluster\n");
    adjtable_ent *tmp;
adjtable_ent *tmp_prev = NULL;


if(primary)
{
tmp = adjtable_1;
}
else
{
tmp = adjtable_2;
}
while(tmp && (tmp->neighbor_cluster != dest) )
{
tmp_prev = tmp;
tmp = tmp->next;
}


if(tmp)
{

    if (tmp_prev)
    {
        tmp_prev->next = tmp->next;
    }
    else
    {
        if(primary)
        {
            adjtable_1 = tmp->next;
        }
        else
        {
            adjtable_2 = tmp->next;
        }
    }
    if(primary)
    {
        adjtable_size1--;
    }
    else
    {
        adjtable_size2--;
    }
       
    delete tmp;

}


if(adjtable_size2 == 0 && (my_status ==  DIST_GW || my_status == FULL_GW))
{
 my_status = ORDINARY_NODE;
 my_rival = 255;
}



}

bool GDSRNeighborTable::isNeighbor(nsaddr_t addr)
{
    ntable_ent *ent = GetEntry(addr);
    
    if (ent)
    {
        return true;
    }
    else
        return false;
}


void GDSRNeighborTable::reCalculateMemberState()
{
    printf("In reCalculateMemberState\n");
   
    }




void GDSRNeighborTable::changeMemberState()
{
    printf("In changeMemberState\n");
  
}


void GDSRNeighborTable::changeMemberState(Packet *p)
{
    printf("In changeMemberState()\n");
    hdr_ip *iph = HDR_IP(p);
    hdr_cmn *cmh = HDR_CMN(p);
   
    if (my_status == ORDINARY_NODE)
    {

        printf("I'm ORDINARY\n");

             if (iph->clusterhead[0] == my_label )
        {
                 printf("The same label\n");
           
            int count = 0;
            adjtable_ent *ent;
            for (int i = 1; i <= iph->num_adj_clusters(); i++)
            {
                if(iph->clusterhead[i] != 255)
                {
                printf("Check %i in adjtable\n",iph->clusterhead[i]);
                ent = GetAdjEntry(iph->clusterhead[i], 0);
                if(ent) count++;
                }
            }

            printf("count = %i\n",count);

            if(iph->node_id() == my_rival)
            {
                   if(((count < adjtable_size2) && (count == iph->num_adj_clusters()))
                           || ((count != iph->num_adj_clusters()) && (count != adjtable_size2)))
                {
                my_status = DIST_GW;
                my_rival = 255;

               }
            }
            else
            {
                
                      
           if(iph->state() == FULL_GW || iph->state() == DIST_GW)
           {


            ntable_ent *entry = GetEntry(my_rival);

               if((count < adjtable_size2) && (count == iph->num_adj_clusters()) &&
                       ((!entry || (entry->neighbor_status != FULL_GW && entry->neighbor_status != DIST_GW))))
            {
                my_status = DIST_GW;
                my_rival = 255;

            }




            }

           }
             


           }
             else
             {

                 printf("Different label\n");
                 printf("my_rival =  %i\n",my_rival);
                  ntable_ent *entry = GetEntry(my_rival);

              if((!entry || (entry->neighbor_status != FULL_GW && entry->neighbor_status != DIST_GW)))
              {
                  my_status = DIST_GW;
                  my_rival = 255;
              }

             }
        
        
          
    }
    else if (my_status == FULL_GW || my_status == DIST_GW)
    {
        
        printf("I'm FULL_GW/DIST_GW\n");
                     if(iph->clusterhead[0] == my_label)
        {
                         printf("The same label\n");
         //   if((iph->state() == FULL_GW || iph->state() == DIST_GW || iph->state() == ORDINARY_NODE))
            if((iph->state() == FULL_GW || iph->state() == DIST_GW))
            {
            int count = 0;
            int count1 = 0;
            adjtable_ent *ent;
            for (int i = 1; i <= iph->num_adj_clusters(); i++)
            {
                if(iph->clusterhead[i]  != 255)
                {
                    printf("Check %i in adjtable\n",iph->clusterhead[i]);
                count1++;
                ent = GetAdjEntry(iph->clusterhead[i], 0);
                if(ent) count++;
                }
            }

            printf("count = %i\n",count);

                 if((count == adjtable_size2) && (count))
            {
                       if(count < count1)
                        {
                          my_status = ORDINARY_NODE;
                          my_rival = iph->node_id();
                         }
                       else
                         {
                          if(a->net_id.getNSAddr_t() > iph->node_id())
                           {
                           my_status = ORDINARY_NODE;
                            my_rival = iph->node_id();
                           }

                         }


              }




            }

        }


        
      


    }
}



/*
void GDSRNeighborTable::changeMemberState(Packet *p)
{
    printf("In changeMemberState()\n");
    hdr_ip *iph = HDR_IP(p);
    hdr_cmn *cmh = HDR_CMN(p);
    if (my_status == INITIAL_NODE )
    {
        if (iph->state() != CLUSTER_HEAD)
        {
        my_status = CLUSTER_HEAD;
        my_label = a->net_id.getNSAddr_t();
        }
        else
        {
        last_status = INITIAL_NODE;
        my_status = ORDINARY_NODE;
        my_label = iph->node_id();
        }
    }
    else if (my_status == ORDINARY_NODE)
    {
             if (iph->clusterhead[0] != my_label && iph->clusterhead[0] != 255 && my_label != 255 )
          {

          my_status = DIST_GW;

          }

    }
    else if (my_status == FULL_GW || my_status == DIST_GW)
    {
                 if(!adjtable_size1)
            {

                my_status = ORDINARY_NODE;

           }


}
}
*/




Packet* GDSRNeighborTable::sendUnicastCluster()
{
    Packet *p = a->allocpkt();
    hdr_ip *iph = HDR_IP(p);
    hdr_cmn *hdrc = HDR_CMN(p);

    adjtable_ent *prte;

    unsigned char *walk;
    unsigned char *count_pos;

    int count;

    hdrc->ptype() = PT_MESSAGE;
    hdrc->direction() = hdr_cmn::DOWN;
    hdrc->next_hop() = MAC_BROADCAST;
    hdrc->addr_type() = NS_AF_INET;

    iph->daddr() = IP_BROADCAST;
    iph->dport() = RT_PORT;
    iph->saddr() = a->net_id.getNSAddr_t();
    iph->sport() = RT_PORT;

    iph->node_id() = a->net_id.getNSAddr_t();
    iph->clusterhead[0] = my_label;
    iph->state() = my_status;


    p->allocdata(adjtable_size1 + 5);

    walk = p->accessdata();
    *(walk)++ = adjtable_size1;

    prte = adjtable_1;
    while(prte)
    {
        *(walk)++ = prte->neighbor_cluster;
        prte = prte->next;
    }

    hdrc->size() = adjtable_size1 * 4 + 5;
    return p;
}


void GDSRNeighborTable::DeleteAdjEntry(nsaddr_t dest, int primary)
{
adjtable_ent *tmp;
adjtable_ent *tmp_prev = NULL;

nexthop_ent *hop = NULL;
nexthop_ent *hop_prev = NULL;

if(primary)
{
tmp = adjtable_1;
}
else
{
tmp = adjtable_2;
}
printf("In DeleteAdjEntry: adjtable_size1= %i, adjtable_size2 = %i\n", adjtable_size1, adjtable_size2);
while(tmp)
{
    NEXT:
hop = tmp->next_hop;
hop_prev = NULL;

while(hop )
{

    if(hop->next_node == dest)
    {
        if(hop_prev)
        {
            hop_prev->next = hop->next;

        }
        else
        {
            tmp->next_hop = hop->next;
        }


if(!tmp->next_hop)
{
    if (tmp_prev)
    {
        tmp_prev->next = tmp->next;

    }
    else
    {
        if(primary)
        {
            adjtable_1 = tmp->next;
        }
        else
        {
           adjtable_2 = tmp->next;
        }

    }

    adjtable_ent *tm = tmp->next;
    delete tmp;
    tmp = tm;

    if(primary)
    {
        adjtable_size1--;
    }
    else
    {
        adjtable_size2--;
    }


    delete hop;
    if(!tmp)
    {
        return;
    }
    
    goto NEXT;
    } else
    {
    delete hop;
    break;
    }
    }
    hop_prev = hop;
    hop = hop->next;

}
tmp_prev = tmp;
tmp = tmp->next;
}


if((adjtable_size2 == 0) && (my_status ==  DIST_GW || my_status == FULL_GW))
        {
            my_status = ORDINARY_NODE;
            my_rival = 255;
        }

/*
if(adjtable_size1 == 0 && (my_status ==  DIST_GW || my_status == FULL_GW))
        {
            my_status = ORDINARY_NODE;
            my_rival = 255;
        }
*/

}


void GDSRNeighborTable::startUp()
{
    Scheduler &s = Scheduler::instance();

   // s.schedule(periodic_handler, periodic_event, jitter(GDSR_STARTUP_JITTER, a->be_random_));
}

void GDSRNeighborTable::DeleteNextnodeToNextCluster(nsaddr_t dest, nsaddr_t nextnode, int primary)
{
adjtable_ent *tmp;
adjtable_ent *tmp_prev = NULL;

nexthop_ent *hop = NULL;
nexthop_ent *hop_prev = NULL;

if(primary)
{
tmp = adjtable_1;
}
else
{
tmp = adjtable_2;
}
printf("In DeleteAdjEntry: adjtable_size1= %i, adjtable_size2 = %i\n", adjtable_size1, adjtable_size2);
while(tmp && tmp->neighbor_cluster != dest)
{
    tmp_prev = tmp;
    tmp = tmp->next;
}


if(tmp)
{
hop = tmp->next_hop;
hop_prev = NULL;

while(hop )
{

    if(hop->next_node == nextnode)
    {
        if(hop_prev)
        {
            hop_prev->next = hop->next;

        }
        else
        {
            tmp->next_hop = hop->next;
        }


if(!tmp->next_hop)
{
    if (tmp_prev)
    {
        tmp_prev->next = tmp->next;

    }
    else
    {
        if(primary)
        {
            adjtable_1 = tmp->next;
        }
        else
        {
           adjtable_2 = tmp->next;
        }

    }

    adjtable_ent *tm = tmp->next;
    delete tmp;
    tmp = tm;

    if(primary)
    {
        adjtable_size1--;
    }
    else
    {
        adjtable_size2--;
    }


    delete hop;
    if(!tmp)
    {
        return;
    }

    } else
    {
    delete hop;
    break;
    }
    }
    hop_prev = hop;
    hop = hop->next;

}


}


if((adjtable_size2 == 0) && (my_status ==  DIST_GW || my_status == FULL_GW))
        {
            my_status = ORDINARY_NODE;
            my_rival = 255;
        }



}
