#include <stdio.h>
#include "hdr_gdsr.h"
#include <dsr/hdr_sr.h>

int hdr_gdsr::offset_;

static class GDSRHeaderClass : public PacketHeaderClass {
public:
	GDSRHeaderClass() : PacketHeaderClass("PacketHeader/GDSR",
					     sizeof(hdr_gdsr)) {
		offset(&hdr_gdsr::offset_);


	}
#if 0
	void export_offsets() {
		field_offset("valid_", OFFSET(hdr_gdsr, valid_));
		field_offset("num_addrs_", OFFSET(hdr_gdsr, num_addrs_));
		field_offset("cur_addr_", OFFSET(hdr_gdsr, cur_addr_));
	}
#endif
} class_GDSRhdr;

char *
hdr_gdsr::dump()
{
  static char buf[100];
  dump(buf);
  return (buf);
}

void
hdr_gdsr::dump(char *buf)
{
  char *ptr = buf;
  *ptr++ = '[';
  for (int i = 0; i < num_addrs_; i++)
    {
       ptr += sprintf(ptr, "%s%d ",
		     (i == cur_addr_) ? "|" : "",addrs[i].addr);
    }
  *ptr++ = ']';
  *ptr = '\0';
}

