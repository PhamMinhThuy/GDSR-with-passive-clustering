/* 
 * File:   gdsragent.h
 * Author: root
 *
 * Created on January 14, 2011, 10:32 PM
 */

#ifndef GDSRAGENT_H
#define	GDSRAGENT_H




#include <agent.h>
#include <ip.h>
#include <delay.h>
#include <scheduler.h>
#include <queue.h>
#include <trace.h>
#include <timer-handler.h>
#include <random.h>
#include <classifier-port.h>
#include <ll.h>
#include <mac.h>
#include <arp.h>
#include <priqueue.h>
#include <dsr/path.h>
#include <dsr/routecache.h>
#include <dsr/requesttable.h>
#include "config.h"
#include "scheduler.h"
#include "queue.h"
#include "ntable.h"
#include "gdsr_pkt.h"
#include "hdr_gdsr.h"
#include <dsr-priqueue.h>
#include <mobilenode.h>
#include <agent.h>




#define BUFFER_CHECK 0.03
#define SEND_TIMEOUT 15.0
#define SEND_BUF_SIZE 64


#define GRAT_ROUTE_ERROR 0

class GDSR_Agent;
class GDSRNeighborTable;
class GDSRNeighborTablePeriodicHandler;
class GDSRNeighborTableFormationHandler;
class GDSRNeighborTableTimeoutHandler;
class ntable_ent;
class nexthop_ent;

class CLUSTER_HEAD_statistics;
class TOTAL_CLUSTER_HEAD;

class CLUSTER_HEAD_statistics
{
public:
    CLUSTER_HEAD_statistics() {bzero(this, sizeof(struct CLUSTER_HEAD_statistics));}
    nsaddr_t clusterhead;
    int neighbors;
    CLUSTER_HEAD_statistics *next;
};

class TOTAL_CLUSTER_HEAD
{
public:
    TOTAL_CLUSTER_HEAD() {bzero(this, sizeof(struct TOTAL_CLUSTER_HEAD));}
    CLUSTER_HEAD_statistics *head_total;
    int size_total;
};

struct GDSR_SendBuffEntry
{
  Time t;
  GDSR_Packet p;
};

class GDSR_SendBufferTimer : public TimerHandler
{
public:
    GDSR_SendBufferTimer(GDSR_Agent *a) : TimerHandler() {a_ = a;}
    void expire (Event *e);
protected:
    GDSR_Agent *a_;
};

class GDSR_Agent : public Tap, public Agent
//class CLUSTER_Agent : public Agent
{
    friend class GDSRNeighborTable;
    friend class GDSRNeighborTablePeriodicHandler;
    friend class GDSRNeighborTableFormationHandler;
    friend class GDSRNeighborTableTimeoutHandler;
    friend class GDSRNeighborTableContentionHandler;
    friend class GDSR_SendBufferTimer;

    //add by Thuy for capturing RTS or ACK
   // friend class Mac802_11;

public:
    GDSR_Agent();
    virtual int command(int argc, const char* const *argv);
    virtual void recv(Packet*, Handler* callback = 0);
    void Terminate(void);
    static int no_of_clusters_;
    static int no_of_errors_;
    static int no_of_initiated_errors_;
    static int no_of_broken_before_dest;
    static int no_of_initiated_rreqs_;
    static int total_path_length_;
    void tap(const Packet *p);

protected:
    void startUp();
    void trace(char *fmt,...);
    void tracepkt(Packet*, double, int, const char*);
    void resetBufferTimer(Event* e);


    void forwardSRPacket(Packet *);
    int myaddr_;
    int be_random_;
    int accessible_var_;
    inline int& accessible_var() {return accessible_var_;}

   // PortClassifier* dmux_;
    Trace* logtarget;
    CMUPriQueue *ll_queue;
    GDSRNeighborTable *ntable;


    

    int use_mac_;
    int verbose_;
    int trace_wst_;

private:
    NsObject *ll;

    ID net_id, MAC_id;
   CMUPriQueue *ifq;

    Mac *mac_;

    MobileNode *node_;
    NsObject *port_dmux_;    // my port dmux

    GDSR_SendBufferTimer send_buf_timer;
    GDSR_SendBuffEntry send_buf[SEND_BUF_SIZE];


    RequestTable request_table;

    //add for reply
    RequestTable reply_table;
    RequestTable error_table;
    RouteCache *route_cache;

    int route_request_num;

    bool route_error_held;
    ID err_from, err_to;
    Time route_error_data_time;


    void handlePktWithoutSR(GDSR_Packet& p, bool retry);
    void handlePacketReceipt(GDSR_Packet& p);
    void handleForwarding (GDSR_Packet& p);
    void handleRREQ(GDSR_Packet &p);
    bool ignoreRouteRequest(GDSR_Packet& p);
    void sendOutPacketWithRoute(GDSR_Packet& p, bool fresh, Time delay = 0.0);

    void sendOutRtReq(GDSR_Packet& p, int max_prop = MAX_SR_LEN);
    void getRouteForPacket(GDSR_Packet &p, bool retry);

    void BroadcastRREQ(GDSR_Packet &p);
    int UnicastRREQ(GDSR_Packet &p, nsaddr_t nextcluster);
    void fillGDSRPath(Path &path, hdr_sr *&clusterh);




    int handleRREP(GDSR_Packet &p);
    void acceptRREP(GDSR_Packet &p);
    void returnSrcRouteToRequestor(GDSR_Packet &p);


    bool replyFromRouteCache(GDSR_Packet &p);




    void processBrokenRouteError(GDSR_Packet& p);
    //void xmitFailed(Packet *pkt);
     void xmitFailed(Packet *pkt, const char* reason = "DROP_RTR_MAC_CALLBACK");
    //void undeliverablePkt(Packet *p, int mine);
     int undeliverablePkt(Packet *p, int mine);

     void xmitSucceed(Packet *pkt);

    void dropSendBuff(GDSR_Packet &p);
    void stickPacketInSendBuffer(GDSR_Packet &p);
    void sendBufferCheck();

     void testinit();
     friend void GDSR_XmitFailureCallback(Packet *pkt, void *data);
     friend int GDSR_FilterFailure(Packet *p, void *data);

     friend void GDSR_XmitSucceedCallback(Packet *pkt, void *data);

};


//static CLUSTER_Agent total_cluster;
static TOTAL_CLUSTER_HEAD cluster;

static bool BackOffTest(Entry *e, Time time);



#endif	/* GDSRAGENT_H */

