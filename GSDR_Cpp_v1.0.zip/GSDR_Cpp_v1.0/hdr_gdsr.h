/* 
 * File:   hdr_gdsr.h
 * Author: root
 *
 * Created on January 14, 2011, 10:27 PM
 */

#ifndef HDR_GDSR_H
#define	HDR_GDSR_H




#include <assert.h>
#include <packet.h>
#include <dsr/hdr_sr.h>


#define GDSR_HDR_SZ 5

#define MAX_CLUSTER_LEN 20		// longest source route we can handle
#define MAX_ROUTE_ERRORS 3	// how many route errors can fit in one pkt?
#define MAX_NEIGHBORS 10



struct link_down_gdsr {         //This is the same as DSR's link_down struct
  int addr_type;		/* same as hdr_cmn in packet.h */
  nsaddr_t tell_addr;		// tell this host
  nsaddr_t from_addr;		// that from_addr host can no longer
  nsaddr_t to_addr;		// get packets to to_addr host
};




struct hdr_gdsr {

    //add cluster-related information
  nsaddr_t label;// I Add  2 lines to support cluster label for CLUSTER_Packet
  uint status;


  int valid_;	  /* is this header actually in the packet? and initialized? */

  int num_addrs_;
  int cur_addr_;
  struct sr_addr addrs[MAX_CLUSTER_LEN];

  int route_request_;	/* is this a route request? 0 for no-request,
                        1 for route request */
  nsaddr_t request_destination_; /* the node to whom the RREQ is made */

  int rtreq_seq_;	// route request sequence number
  int max_propagation_;

  int route_reply_;	// is the reply below valid?
  int route_reply_len_;
  struct sr_addr reply_addrs_[MAX_CLUSTER_LEN];

  

  int num_forwarders_;

  int route_shortened_;//if a node shortens the source route, it sets this flag
  int route_shortening_; /* when I shorten the route, the new route might or might or not work
                            because of the shortening.  I'd better don't modify the route first,
                            but set this flag.  If the route works, the node after me could
                            modify the route and change the route_shortened flag.. */

  int route_repaired_; //if a node repairs the source route, it sets this flag

  int route_error_;		/* are we carrying a route reply? inherited from
                                   DSR -Jinyang */

  int num_route_errors_;
  struct link_down_gdsr down_links_[MAX_ROUTE_ERRORS];

  //static int offset_;		/* offset for this header */
  //inline int& offset() { return offset_; }

  inline int& valid() {return valid_;}
  inline int& num_addrs() {return num_addrs_;}
  inline int& cur_addr() {return cur_addr_;}


  inline int& route_request() {return route_request_;}
  inline nsaddr_t& request_destination() {return request_destination_;}
  inline int& rtreq_seq() {return rtreq_seq_;}
  inline int& max_propagation() {return max_propagation_;}

  inline int& route_reply() {return route_reply_;}
  inline int& route_reply_len() {return route_reply_len_;}
  inline struct sr_addr* reply_addrs() {return reply_addrs_;}

  inline int& num_forwarders(){return num_forwarders_;}

  inline int& route_shortened() { return route_shortened_;}
  inline int& route_shortening() { return route_shortening_;}
  inline int& route_repaired() {return route_repaired_;}

  inline int& route_error() {return route_error_;}
  inline int& num_route_errors() {return num_route_errors_;}
  inline struct link_down_gdsr* down_links() {return down_links_;}

  inline nsaddr_t& get_next_addr() {
    assert(cur_addr_ < num_addrs_);
    return (addrs[cur_addr_ + 1]).addr; }

  inline void append_addr(nsaddr_t a, int type) {
    assert(num_addrs_ < MAX_GDSR_LEN-1);
    addrs[num_addrs_].addr_type = type;
    addrs[num_addrs_++].addr = a; }

  inline void init() {

    valid_ = 1;

    num_addrs_ = 0;
    cur_addr_ = 0;
    route_request_ = 0;
    rtreq_seq_ = 0;
    route_reply_ = 0;
    route_reply_len_ = 0;
    num_forwarders_ = 0;
    route_repaired_ = 0;
    route_shortened_ = 0;
    route_shortening_ = 0;
    route_error_ = 0;
    num_route_errors_ = 0;

  }

  inline int size() {
	int sz = GDSR_HDR_SZ +
		 4 * (num_addrs_ -1)+
		 4 * (route_reply_ ? route_reply_len_ : 0) +
                 8 * (route_request_? num_forwarders_ : 0) +
		 8 * (route_error_? num_route_errors_ : 0);
	assert(sz >= 0);
	return sz;
 


  /*
      int sz = 0;
        if (num_addrs_ || route_request() ||
                route_reply() || route_error())
            sz += SR_HDR_SZ;

        if (num_addrs_) sz += 4 * (num_addrs_ - 1);
        if (route_reply()) sz += 5 + 4 * route_reply_len();
        if (route_request()) sz += 8 + 8 * num_forwarders();
        if (route_error()) sz += 16 * num_route_errors();


     

        sz = ((sz + 3)&(~3)); // align...
        assert(sz >= 0);
        return sz;
        */

  }
  void dump(char *);
  char* dump();

  public:
	static int offset_;		/* offset for this header */
	inline int& offset() { return offset_; }
        inline static hdr_gdsr* access(const Packet* p) {
	        return (hdr_gdsr*)p->access(offset_);
	}
};







#endif	/* HDR_GDSR_H */

