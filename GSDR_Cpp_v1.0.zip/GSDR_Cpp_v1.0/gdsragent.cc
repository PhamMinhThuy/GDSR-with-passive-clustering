extern "C" {
#include <stdarg.h>
#include <float.h>
}

#include "gdsragent.h"
#include "gdsr_pkt.h"
#include "dsr/hdr_sr.h"
#include "config.h"
#include "scheduler.h"
#include "queue.h"
#include <cmu-trace.h>
#include <mac-802_11.h>
#include <random.h>
#include <trace.h>
#include <packet.h>
#include <agent.h>
#include "ntable.h"
#include "common/packet.h"
#include "trace/trace.h"
#include "tools/random.h"
#include "common/ip.h"
#include "queue/queue.h"
#include "mobile/god.h"
#include "queue/dsr-priqueue.h"
#include "routing/address.h"
#include <address.h>
#include <delay.h>
#include <ip.h>
#include <ll.h>
#include <scheduler.h>
#include <god.h>






#define GDSR_ALMOST_NOW 0.1
#define GDSR_IP_DEF_TTL 32

#define MAX_LOCAL_REPAIR_TIMES 5



static const int verbose_srr = 0;

bool gdsr_use_tap = false;
//bool gdsr_use_tap = true;
bool gdsragent_reply_from_cache_uninvited = false;
bool gdsr_snoop_source_routes = false;
//bool gdsr_reply_only_to_first_rtreq = false;
bool gdsr_reply_only_to_first_rtreq = true;
bool gdsr_reply_from_cache_on_propagating = false;
bool gdsr_shortening_route_if_possible = true;
bool gdsr_snoop_forwarded_errors = true;
bool gdsr_propagate_last_error = false;


bool gdsr_local_repair = true;

bool gdsr_salvage_with_cache = true;


Time gdsr_rt_rq_period = 0.5;
Time gdsr_rt_rq_max_period = 10.0;
Time gdsr_arp_timeout = 30.0e-3;
Time gdsr_max_err_hold = 1.0;

int GDSR_Agent::no_of_errors_ = 0;
int GDSR_Agent::no_of_initiated_errors_ = 0;
int GDSR_Agent::no_of_initiated_rreqs_ = 0;
int GDSR_Agent::total_path_length_ = 0;
class GDSR_Agent;

/*
int hdr_sr::offset_;
static class GDSRHeaderClass : public PacketHeaderClass
{
public:
    GDSRHeaderClass() : PacketHeaderClass("PacketHeader/GDSR", sizeof(hdr_sr))
    {
        bind_offset(&hdr_sr::offset_);
    }
} class_gdsrhdr;
*/

static inline double jitter(double max, int be_random_)
{
    return(be_random_ ? Random::uniform(max) : 0);
}

struct filterfailuredata
{
    nsaddr_t dead_next_hop;
    int off_cmn_;
    GDSR_Agent *agent;
};


void GDSR_XmitFailureCallback(Packet *pkt, void *data)
{
    GDSR_Agent *agent = (GDSR_Agent *)data;
    agent->xmitFailed(pkt);
}


void GDSR_XmitSucceedCallback(Packet *pkt, void *data)
{
    GDSR_Agent *agent = (GDSR_Agent *)data;
    agent->xmitSucceed(pkt);
}


int GDSR_FilterFailure(Packet *p, void *data)
{
    struct filterfailuredata *ffd = (filterfailuredata* ) data;
    hdr_cmn *cmh = HDR_CMN(p);
    int remove = cmh->next_hop() == ffd->dead_next_hop;
    if(remove) ffd->agent->undeliverablePkt(p,1);
    return remove;
}





static class GDSRClass : public TclClass
{
public:
    GDSRClass() : TclClass("Agent/GDSR") {}
    TclObject *create(int, const char*const* )
    {
        return (new GDSR_Agent());
    }
} class_gdsr;


GDSR_Agent::GDSR_Agent():Agent(PT_GDSR),myaddr_(0),be_random_(1),ll_queue(0),use_mac_(0),verbose_(1), trace_wst_(0),send_buf_timer(this),request_table(128), route_cache(NULL)
{
    ntable = new GDSRNeighborTable(this);
    route_cache = makeRouteCache();


    route_request_num = 1;
    target_ = 0;
   ll = 0;
   mac_ = 0;
   ifq = 0;
    logtarget = 0;

    route_error_held = false;

  //bind("myaddr_", &myaddr_);
    bind("be_random_", &be_random_);
  //  bind("no_of_clusters_", &no_of_clusters_);
 //   bind_bool("accessible_var_", &accessible_var_);

    bind("use_mac_", &use_mac_);
    bind("verbose_", &verbose_);
    bind("trace_wst_", &trace_wst_);
}

void GDSR_Agent::startUp()
{
    //kick off periodic advertisments
    printf("\nBegin CLUSTER_Agent::startUp().Now Scheduler::instance().clock() = %3.2f\n", Scheduler::instance().clock());
   // printf("Call the startUp() from the CLUSTER_Agent of node %i\n", myaddr_);
  //  ntable->startUp();
    //printf("In CLUSTER_Agent::startUp(), target_ = %d\n",target_);
}

int GDSR_Agent :: command(int argc, const char*const *argv)
{
    TclObject *obj;
    if (argc == 2)
    {
        if (strcmp(argv[1], "startgdsr") == 0)
        {
           // printf("\nWhen CLUSTER_Agent receives command startcluster: target_ = %d\n", target_);
            startUp();
           // printf("After startUp() in CLUSTER_Agent, target_ = %d\n",target_);
            send_buf_timer.sched(BUFFER_CHECK + BUFFER_CHECK *Random::uniform(1.0));
            return (TCL_OK);
        }
        else if (strcmp(argv[1], "testinit") == 0)
        {
            testinit();
            return(TCL_OK);
        }
        else if (strcmp(argv[1], "reset") == 0)
        {
            Terminate();
            return Agent::command(argc, argv);
        }
        else if (strcasecmp(argv[1], "check-cache") == 0)
        {
            return route_cache->command(argc, argv);
        }
      /*  else if (strcasecmp(argv[1], "ll-queue") == 0)
        {
            if (!(ll_queue = (CMUPriQueue*) TclObject::lookup(argv[2])))
            {
                fprintf(stderr, "GDSR_Agent: ll-queue lookup of %s failed \n", argv[2]);
                return TCL_ERROR;
            }
            return TCL_OK;
        }
*/
    }
    else if (argc == 3)
    {


        if (strcasecmp(argv[1], "addr") == 0)
        {
           // net_id = ID(atoi(argv[2]), ::IP);
            net_id = ID(Address::instance().str2addr((argv[2])), ::IP);
            myaddr_ = net_id.addr;
            route_cache->net_id = net_id;
            return TCL_OK;
        }
        else if (strcasecmp(argv[1], "mac-addr") == 0)
        {
            MAC_id = ID(atoi(argv[2]), ::MAC);
            route_cache->MAC_id = MAC_id;
            return TCL_OK;
        }

        if ((obj = TclObject::lookup(argv[2])) == 0)
        {
            fprintf(stderr, "GDSR_Agent: %s lookup of %s failed\n", argv[1], argv[2]);
            return TCL_ERROR;
        }
        if (strcasecmp(argv[1], "log-target") == 0)
        {
            logtarget = (Trace*)obj;
            return route_cache->command(argc, argv);
        }
        else if (strcasecmp(argv[1], "tracetarget") == 0 )
       	{
	  logtarget = (Trace*) obj;
	  return route_cache->command(argc, argv);
	}
        else if (strcasecmp(argv[1], "install-tap") == 0)
	{
	  mac_ = (Mac*) obj;
	  mac_->installTap(this);
	  return TCL_OK;
	}
         else if (strcasecmp(argv[1], "node") == 0)
	{
	  node_ = (MobileNode *) obj;
	  return TCL_OK;
	}
      else if (strcasecmp (argv[1], "port-dmux") == 0)
	{
	  port_dmux_ = (NsObject *) obj;
	  return TCL_OK;
	}
    }
    else if (argc == 4)
    {
        if (strcasecmp(argv[1], "add-ll") == 0)
        {
            if ((obj = TclObject::lookup(argv[2])) == 0)
            {
                fprintf(stderr, "GDSR_Agent: %s lookup of %s failed\n", argv[1], argv[2]);
                return TCL_ERROR;
            }
            ll = (NsObject*)obj;
            if ((obj = TclObject::lookup(argv[3])) == 0)
            {
                fprintf(stderr, "GDSR_Agent: %s lookup of %s failed \n", argv[1], argv[3]);
                return TCL_ERROR;
            }
            ifq = (CMUPriQueue*)obj;
            return TCL_OK;
        }
    }
    return Agent::command(argc,argv);
}

void GDSR_SendBufferTimer::expire(Event* e)
{
   // printf("In CLUSTER_SendBufferTimer::exipre\n");
    a_->sendBufferCheck();
    a_->resetBufferTimer(e);
}

void GDSR_Agent::resetBufferTimer(Event *e)
{
 // send_buf_timer.resched(BUFFER_CHECK + BUFFER_CHECK * (double)((int) e>>5 & 0xff) /256.0);
    send_buf_timer.resched(BUFFER_CHECK + BUFFER_CHECK * Random::uniform(1.0));
}


void GDSR_Agent::dropSendBuff(GDSR_Packet& p)
{
    printf("In dropSendBuff\n");
    trace("Ssb %.5f _%s_ dropped %s -> %s", Scheduler::instance().clock(), net_id.dump(), p.src.dump(), p.dest.dump());
    drop(p.pkt, DROP_RTR_QTIMEOUT);
    p.pkt = 0;
    p.route.reset();
}


void GDSR_Agent::stickPacketInSendBuffer(GDSR_Packet& p)
{
    printf("In stickPacketInSendBuffer\n");
    Time min = DBL_MAX;
    int min_index = 0;
    int c;



    if(verbose_)
    {
        trace("Sdebug %.5f _%s_ stuck into send buff %s -> %s", Scheduler::instance().clock(), net_id.dump(), p.src.dump(), p.dest.dump());
    }


    for (c = 0; c < SEND_BUF_SIZE; c++)
        if (send_buf[c].p.pkt == NULL)
        {
            send_buf[c].t = Scheduler::instance().clock();
            send_buf[c].p = p;
            return;
        }
        else if (send_buf[c].t < min)
        {
            min = send_buf[c].t;
            min_index = c;
        }
    dropSendBuff(send_buf[min_index].p);
    send_buf[min_index].t = Scheduler::instance().clock();
    send_buf[min_index].p = p;

}

void GDSR_Agent::sendBufferCheck()
{
  //  printf("In sendBufferCheck() of node %i\n", net_id.addr);
    int c;

    for (c = 0; c < SEND_BUF_SIZE; c++)
    {
        if (send_buf[c].p.pkt == NULL) continue;
        if ((Scheduler::instance().clock() - send_buf[c].t > SEND_TIMEOUT) || (HDR_SR(send_buf[c].p.pkt)->route_repaired() == 7))
     //   if (Scheduler::instance().clock() - send_buf[c].t > SEND_TIMEOUT)
     //   if ((Scheduler::instance().clock() - send_buf[c].t > SEND_TIMEOUT) || (send_buf[c].p.dest == send_buf[c].p.src))
     //   if ((Scheduler::instance().clock() - send_buf[c].t > SEND_TIMEOUT) || (send_buf[c].p.dest == send_buf[c].p.src) || HDR_IP(send_buf[c].p.pkt)->daddr() == -1)
        {
            dropSendBuff(send_buf[c].p);
            send_buf[c].p.pkt = 0;
            continue;
        }

#ifdef DEBUG
        trace("Sdebug %.5f _%s_ checking for route for dst %s", Scheduler::instance().clock(), net_id.dump(), send_buf[c].p.dest.dump());
#endif
        if((HDR_SR(send_buf[c].p.pkt)->route_repaired() == 6))
        {
            HDR_SR(send_buf[c].p.pkt)->route_repaired() == 7;
            continue;
        }

        // printf("In sendBufferCheck, no goto handlePktWithoutSR\n");
       //  printf("send_buf[%i].p is not NULL\n",c);
        handlePktWithoutSR(send_buf[c].p, true);


#ifdef DEBUG
        if(send_buf[c].p.pkt == NULL)
            trace("Sdebug %.5f _%s_ sendbuf pkt to %s liberated by handlePktWithoutSR", Scheduler::instance().clock(), net_id.dump(), send_buf[c].p.dest.dumpJ());
#endif
    }
}


/*
void CLUSTER_Agent::recv(Packet* p, Handler*)
{
    printf("\nBegin CLUSTER_Agent::recv().Now Scheduler::instance().clock() = %3.2f\n", Scheduler::instance().clock());
    hdr_ip *iph = HDR_IP(p);
    hdr_cmn *cmh = HDR_CMN(p);
    hdr_cluster *clusterh = hdr_cluster::access(p);

   int src = Address::instance().get_nodeaddr(iph->saddr());
   printf("src = %i, myaddr_ =  %i, iph->ttl_ = %i\n", src, myaddr_, iph->ttl_);
    //if ((iph->src_ == myaddr_) && (cmh->num_forwards() == 0))
    //printf("Node %d receive packet from %d \n",myaddr_, src);
   // printf("Node %i receive packet from %i \n",myaddr_, src);
   if (iph->saddr()== myaddr_ && cmh->num_forwards() == 0)
   {
       iph->ttl_ = CLUSTER_IP_DEF_TTL;
   }
   else
   {
       if (--iph->ttl_ == 0)
       {
           drop(p, DROP_RTR_TTL);
           return;
       }
   }

    if (src != myaddr_ && (!clusterh->valid()))
    {
        printf("Node %i receive packet from %i and will get into processUpdate\n", myaddr_, src);
        ntable->processUpdate(p);
    }
    else
   {
        forwardSRPacket(p);
   }
}
*/



void GDSR_Agent::recv(Packet* p, Handler*)
{
    printf("\nBegin GDSR_Agent::recv().Now Scheduler::instance().clock() = %3.2f, net_id.addr = %i\n", Scheduler::instance().clock(),net_id.addr);
    hdr_ip *iph = HDR_IP(p);
    hdr_cmn *cmh = HDR_CMN(p);
    hdr_sr *clusterh = hdr_sr::access(p);

    if (cmh->ptype() == PT_CBR)
    {
        printf("Receive CBR\n");
    }
    else if (cmh->ptype() == PT_GDSR && clusterh->route_request())
    {
        printf("Receive GDSR RREQ\n");
    }
    else if (cmh->ptype() == PT_GDSR && clusterh->route_reply())
    {
        printf("Receive GDSR RREP\n");
    }
    else if (cmh->ptype() == PT_GDSR && clusterh->route_error())
    {
        printf("Receive GDSR RERR\n");
    }
    else if (cmh->ptype() == PT_MESSAGE)
    {
        printf("Receive HELLO message\n");
    }
     else if (cmh->ptype() == PT_ACK)
    {
        printf("Receive ACK\n");
    }
    else if (cmh->ptype() == PT_TCP)
    {
        printf("PT_TCP\n");
    }
    else if (cmh->ptype() == PT_MAC)
    {
        printf("PT_MAC\n");
    }


    

   int src = Address::instance().get_nodeaddr(iph->saddr());
   printf("src = %i, myaddr_ =  %i, iph->ttl_ = %i, net_id.addr = %i\n", src, myaddr_, iph->ttl_, net_id.addr);
   printf("my_label = %i, my_status = %i\n", ntable->my_label, ntable->my_status);
    //if ((iph->src_ == myaddr_) && (cmh->num_forwards() == 0))
    //printf("Node %d receive packet from %d \n",myaddr_, src);
   // printf("Node %i receive packet from %i \n",myaddr_, src);
   printf("src = %i, dst = %i, prev_hop_ = %i\n", iph->saddr(), iph->daddr(),cmh->prev_hop_);
   printf("iph->node_id() = %i, iph->state() = %i, iph->clusterhead[0] = %i\n", iph->node_id(), iph->state(), iph->clusterhead[0]);
   if (iph->saddr()== myaddr_ && cmh->num_forwards() == 0)
   {
       iph->ttl_ = GDSR_IP_DEF_TTL;
   }
   else if(iph->saddr() == myaddr_) {
    if((iph->node_id() != net_id.getNSAddr_t()) && (iph->state()))
       {
            ntable->processUpdate(p);
       }
    drop(p, DROP_RTR_ROUTE_LOOP);
    return;
  } 
   else
   {
       if (--iph->ttl_ == 0)
       {
           drop(p, DROP_RTR_TTL);
          // p = 0;
           return;
       }
   }


    /*

        if (iph->saddr() != myaddr_  && clusterh->valid())
    {
        printf("Node %i receive packet from %i and will get into processUpdate\n", myaddr_, src);
        CLUSTER_Packet pkt(p, clusterh);
        printf("src = %i, clusterh->request_destination() = %i\n", pkt.src.addr, clusterh->request_destination());

        ntable->processUpdate(pkt);
        forwardSRPacket(p);
    }
    else
    {
        printf("Node %i receive packet and will forward it\n", myaddr_);
        forwardSRPacket(p);
    }
*/

   printf("clusterh->valid() =  %i\n", clusterh->valid());



   /*
    if (iph->saddr() != myaddr_  && clusterh->valid())
    {
        printf("Node %i receive packet from %i and will get into processUpdate\n", myaddr_, src);
        Packet * p_copy = p;
        CLUSTER_Packet pkt(p, clusterh);
        printf("src = %i, clusterh->request_destination() = %i\n", pkt.src.addr, clusterh->request_destination());

        ntable->processUpdate(pkt);
        forwardSRPacket(p_copy);
        Packet::free(p_copy);
    }
    else
    {
        printf("Node %i receive packet and will forward it\n", myaddr_);
        printf("clusterh->request_destination() = %i\n", clusterh->request_destination());
        forwardSRPacket(p);
    }
    */


//if ((iph->saddr() != myaddr_)  && (!clusterh->valid()))
    if (cmh->ptype() == PT_MESSAGE)
    {
        printf("Node %i receive packet from %i and will get into processUpdate\n", myaddr_, src);



       ntable->processUpdate(p);
       Packet::free(p);
       p = NULL;

    }
    else
    {
        printf("Node %i receive packet and will forward it\n", myaddr_);
        
       //  if ((iph->node_id() != net_id.getNSAddr_t()) && (iph->saddr() != net_id.getNSAddr_t()))

        //for testing, first just route_request()
    //  if ((iph->node_id() != net_id.getNSAddr_t()) && (clusterh->route_request() || clusterh->route_reply()))
        if((iph->node_id() != net_id.getNSAddr_t()) && (iph->state()))
       {
            ntable->processUpdate(p);
       }

        if(cmh->ptype() == PT_CBR || clusterh->route_error() || clusterh->route_repaired() || clusterh->route_shortened())
        {
            if(iph->clusterhead[0] != ntable->my_label) clusterh->pass_clusterhead() = 0;
            if(ntable->my_status == CLUSTER_HEAD) clusterh->pass_clusterhead() = 1;
        }

        forwardSRPacket(p);
    }




}


void GDSR_Agent::testinit()
{
    struct hdr_sr hsr;
    if (net_id == ID(1, ::IP))
    {
        printf("adding route to 1\n");
        hsr.init();
        hsr.append_addr(1, NS_AF_INET);
        hsr.append_addr(2, NS_AF_INET);
        hsr.append_addr(3, NS_AF_INET);
        hsr.append_addr(4, NS_AF_INET);

        route_cache->addRoute(Path(hsr.addrs(), hsr.num_addrs()), 0.0, ID(1, ::IP));
    }
    if (net_id == ID(3, ::IP))
    {
        printf("adding route to 3\n");
        hsr.init();
        hsr.append_addr(3, NS_AF_INET);
        hsr.append_addr(2, NS_AF_INET);
         hsr.append_addr(1, NS_AF_INET);
        route_cache->addRoute(Path(hsr.addrs(), hsr.num_addrs()), 0.0, ID(3, ::IP));
    }
}

void GDSR_Agent::Terminate()
{
    int c;
    for (c = 0; c < SEND_BUF_SIZE; c++)
    {
        if (send_buf[c].p.pkt)
        {
            drop(send_buf[c].p.pkt,DROP_END_OF_SIMULATION);
            send_buf[c].p.pkt = 0;
        }
    }
}

void GDSR_Agent::tap(const Packet *packet)
{
   // printf("In GDSR_Agent::tap\n");
    hdr_sr *clusterh = hdr_sr::access((Packet*)packet);
    hdr_ip *iph = HDR_IP((Packet*)packet);
    hdr_cmn *cmn = HDR_CMN((Packet*)packet);




    if (!gdsr_use_tap) return;
    if (!clusterh->valid() ) return;

    //ID next_hop(clusterh->addrs()[clusterh->cur_addr()].addr, ::IP);
    ID next_hop(cmn->next_hop(), ::IP);
    if (next_hop == net_id || next_hop == MAC_id) return;

    GDSR_Packet p((Packet*)packet, clusterh);
   // p.dest = ID(iph->daddr(), ::IP);
  //  p.src = ID(iph->saddr(), ::IP);
    p.dest = ID((Address::instance().get_nodeaddr(iph->daddr())),::IP);
    p.src = ID((Address::instance().get_nodeaddr(iph->saddr())),::IP);

  //   printf("Node %i captures packet, iph->saddr() = %i, p.src = %i, p.dest = %i, cmn->prev_hop_ = %i\n", myaddr_, iph->saddr(), p.src.getNSAddr_t(), p.dest.getNSAddr_t(), cmn->prev_hop_);


  //  if (p.src == net_id) return;
  if((p.src == net_id) || (p.dest == net_id) || (cmn->next_hop() == net_id.addr)) return;

  /*
    if(HDR_IP(p.pkt)->node_id() != net_id.addr)
        {
            ntable->processUpdate(p.pkt);
        }
*/

   if((HDR_IP(p.pkt)->node_id() != net_id.getNSAddr_t()) && (HDR_IP(p.pkt)->state()))
       {
            ntable->processUpdate(p.pkt);
       }

    if(clusterh->route_error())
    {
        if(verbose_)
            trace("Sdebug _%s_ tap saw error %d", net_id.dump(), cmn->uid());
        processBrokenRouteError(p);
    }






    if (clusterh->route_reply())
    {

       if(!clusterh->route_shortened() && !clusterh->route_repaired())
        {

   
        Path reply_path(clusterh->reply_addrs(), clusterh->route_reply_len());
       // reply_path.reverseInPlace();


        if(verbose_)
            trace("Sdebug _%s_ tap saw route reply %d %s", net_id.dump(), cmn->uid(), reply_path.dump());
        route_cache->noticeRouteUsed(reply_path, Scheduler::instance().clock(), p.src);

        return;
        }
        else
        {
            Path reply(clusterh->addrs(), clusterh->num_addrs());
            route_cache->noticeRouteUsed(reply, Scheduler::instance().clock(), p.src);
            return;
        }
   
       

    }
  

 /* //  if (clusterh->route_request() && ((unsigned long)iph->daddr()) != IP_BROADCAST)
  if (clusterh->route_request() && ((u_int32_t)iph->daddr() != IP_BROADCAST))
    {
        if (gdsragent_reply_from_cache_uninvited)
        {
            Packet *p_copy = p.pkt->copy();
            p.pkt = p_copy;
          replyFromRouteCache(p);

        }
    }
   // else if (clusterh->route_request() && ((unsigned long)iph->daddr()) == IP_BROADCAST)
  else if (clusterh->route_request() && ((u_int32_t)iph->daddr() == IP_BROADCAST))
    {
        return;
    }
*/
    if (gdsr_snoop_source_routes)
    {
        if(verbose_)
            trace("Sdebug _%s_ tap saw route use %d %s", net_id.dump(), cmn->uid(), p.route.dump());

        if(!clusterh->route_request()) route_cache->noticeRouteUsed(p.route, Scheduler::instance().clock(), net_id);
    }

}




void GDSR_Agent::forwardSRPacket(Packet* packet)
{
    printf("\nIn forwardSRPacket of node %i\n", myaddr_);
    hdr_sr *clusterh = hdr_sr::access(packet);
    hdr_ip *iph = HDR_IP(packet);
    hdr_cmn *cmh = HDR_CMN(packet);

    assert(cmh->size() >= 0);
   GDSR_Packet p(packet, clusterh);


   // p.dest = ID(iph->daddr(), ::IP);
   // p.src = ID(iph->saddr(), ::IP);
    p.dest = ID((Address::instance().get_nodeaddr(iph->daddr())),::IP);
  p.src = ID((Address::instance().get_nodeaddr(iph->saddr())),::IP);


  //  p.route.dump();
    printf("clusterh->num_addrs() = %i\n", clusterh->num_addrs());
    for (int i = 0; i < clusterh->num_addrs(); i++)
    {
        printf("p.route[%i] = %i\n",i,  p.route[i].getNSAddr_t());
    }




    assert(logtarget!= 0);

    if (!clusterh->valid())
    {
        clusterh->init();

        if(verbose_)
            trace("S %.9f _%s_ originating %s -> %s", Scheduler::instance().clock(), net_id.dump(), p.src.dump(), p.dest.dump());
        cmh->size() += IP_HDR_LEN;
       // cmh->ptype() = PT_CBR;
        printf("Now goto handlePktWithoutSR\n");
        handlePktWithoutSR(p, false);
        goto done;
    }


    if(p.dest == net_id || p.dest == IP_broadcast)
    {
        printf("Goto handlePacketReceipt\n");
        handlePacketReceipt(p);
        goto done;

    }






/*
    if (clusterh->route_request())
    {

        if (ignoreRouteRequest(p))
        {
            printf("The request from %i will be ignored\n", iph->saddr());
            Packet::free(p.pkt);
            return;
        }
        else
        {
        printf("Goto handleRREQ\n");
        handleRREQ(p);
        }
    }
*/
    if (gdsr_snoop_forwarded_errors && clusterh->route_error())
    {

        processBrokenRouteError(p);
       // goto done;
    }



        if (clusterh->route_request())
    {
        printf("Goto handleRREQ\n");
        handleRREQ(p);
    }
// else if (!clusterh->route_repaired() && clusterh->route_reply())
 /*   else if (!clusterh->route_repaired() && !clusterh->route_shortened() && clusterh->route_reply())
  {
     handleRREP(p);
   }*/
    else
    {
        printf("Goto handleForwarding\n");
        handleForwarding(p);
    }




    done:
    assert(p.pkt == 0);
    p.pkt = 0;
    return;
}





//change for cluster label
void GDSR_Agent::handlePktWithoutSR(GDSR_Packet& p, bool retry)
{
    printf("In handlePktWithoutSR of node %i\n", myaddr_);
    hdr_sr *clusterh = hdr_sr::access(p.pkt);
    hdr_ip *iph = HDR_IP(p.pkt);
    hdr_cmn *ch = HDR_CMN(p.pkt);


     printf("HDR_CMN(p.pkt)->size() = %i, gdsrh->size() = %i,gdsrh->valid() = %i, saddr() = %i, daddr() = %i, p.src.addr = %i, p.dest.addr = %i\n", HDR_CMN(p.pkt)->size(), clusterh->size(),clusterh->valid(), iph->saddr(),iph->daddr(),p.src.addr,p.dest.addr);

    assert(clusterh->valid());
   // assert(iph->saddr() == myaddr_);


    if(HDR_IP(p.pkt)->saddr() == HDR_IP(p.pkt)->daddr())
    {
          // Packet::free(p.pkt);
          //  p.pkt = 0;
        recv(p.pkt,(Handler*)0);
        p.pkt = 0;
            return;
    }


    

     if (p.dest == net_id)
    {
      printf("p.dest == net_id\n") ;// handlePacketReceipt(p);
      handlePacketReceipt(p);
      return;
    }



  



    if (route_cache->findRoute(p.dest, p.route, 1))
    {
        printf("route_cache->findRoute()\n");
        if(verbose_)
            trace("S$hit %.5f _%s_ %s -> %s %s", Scheduler::instance().clock(), net_id.dump(), p.src.dump(), p.dest.dump(), p.route.dump());

        sendOutPacketWithRoute(p, true);
        return;
    }


    if (ntable->isNeighbor(p.dest.addr))
    {
        printf("isNeighbor\n");
        p.route.reset();


       p.route.appendToPath(net_id);
          p.route.appendToPath(p.dest);


          if(verbose_)
              trace("S$direct hit %.5f _%s_ %d -> %s %s", Scheduler::instance().clock(), net_id.dump(), iph->saddr(), p.dest.dump(), p.route.dump());

        sendOutPacketWithRoute(p, true);
        return;
    }





    if(verbose_)
        trace("S$miss %.5f _%s_ %s -> %s retry %d", Scheduler::instance().clock(), net_id.dump(), net_id.dump(), p.dest.dump(), retry ? 1 : 0);


    //If this node can't find the destination, it have to send out a RREQ to discover the destination
    getRouteForPacket(p, retry);
}




void GDSR_Agent::handlePacketReceipt(GDSR_Packet& p)
{
    printf("In handlePacketReceipt\n");
    hdr_sr *clusterh = hdr_sr::access(p.pkt);
    hdr_cmn *cmh = HDR_CMN(p.pkt);

    if (clusterh->route_reply() == 1)
    {
        printf("Receive RREP\n");
    }
    else if (clusterh->route_request() == 1)
    {
        printf("Receive RREQ\n");
    }



    if (clusterh->route_reply())
    {
       // printf("Go to acceptRREP(p)\n");
        acceptRREP(p);
      //  printf("Back from acceptRREP(p)\n");
    }



/*
    if (cmh->ptype() == PT_CBR || cmh->ptype() == PT_TCP )
    {
        p.route.reverseInPlace();
        route_cache->addRoute(p.route, Scheduler::instance().clock(), net_id);
    }
*/




    if (clusterh->route_request())
    {
      //  assert((unsigned long)clusterh->request_destination() == net_id.addr || net_id == p.dest);
         assert((u_int32_t) net_id == p.dest);
        if (gdsr_reply_only_to_first_rtreq && ignoreRouteRequest(p))
        {
            printf("Ignore request\n");
            Packet::free(p.pkt);
            p.pkt = 0;
            return;
        }
        else
        {
            printf("Got to return SrcRouteToRequestor\n");
           // request_table.insert(p.src, p.src, clusterh->rtreq_seq());
            //add
            request_table.insert(p.src, p.src, ID(HDR_IP(p.pkt)->node_id(),::IP),clusterh->rtreq_seq());

            returnSrcRouteToRequestor(p);
        }
    }



    if(clusterh->route_error())
    {
        processBrokenRouteError(p);
    }


    if (cmh->ptype() == PT_CBR )
    {
        GDSR_Agent::total_path_length_ += (GDSR_IP_DEF_TTL - HDR_IP(p.pkt)->ttl_);
        trace("total_path_length_ %i\n",GDSR_Agent::total_path_length_);
    }


     if (!clusterh->route_reply() && ((u_int32_t) clusterh->addrs()[0].addr == p.src.addr) &&
             !clusterh->route_error() && ((clusterh->route_repaired() > 5) || (clusterh->route_shortened()) ))
    {
      //  printf("Return RREP\n");


        Entry *e = reply_table.getEntry(p.src);
        Time time = Scheduler::instance().clock();
        Time temp;
        if(e) temp = e->last_rt_req;
        if((BackOffTest(e,time)))
       // if((BackOffTest(e,time) && (time - e->last_arp > 20)) || !e)
      //  if((BackOffTest(e,time) && (time - temp > 2)) || !e)
        {
            e->last_type = UNLIMIT;
            e->last_arp = time;

        GDSR_Packet p_copy = p;
        p_copy.pkt = allocpkt();
        p_copy.dest = p.src;
        p_copy.src = net_id;




        hdr_ip *new_iph = HDR_IP(p_copy.pkt);
        hdr_sr *new_clusterh = hdr_sr::access(p_copy.pkt);

        new_clusterh->init();
        new_clusterh->route_repaired() = clusterh->route_repaired();
      //  new_clusterh->route_shortening() = clusterh->route_shortening();
        new_clusterh->route_shortened() = clusterh->route_shortened();
        new_clusterh->route_reply() = 1;



        new_iph->saddr() = net_id.addr;
        new_iph->daddr() = p.src.addr;
        new_iph->dport() = RT_PORT;
        new_iph->sport() = RT_PORT;
        new_iph->ttl() = 255;


         new_clusterh->reply_addrs()[0].addr = net_id.addr;
        new_clusterh->reply_addrs()[0].addr_type = NS_AF_INET;
        new_clusterh->route_reply_len() = 1;


        p_copy.route.reverseInPlace();
        ::compressPath(p_copy.route);
        p_copy.route.resetIterator();
      //  fillGDSRPath(p_copy.route, new_clusterh);
         hdr_cmn *new_cmnh = HDR_CMN(p_copy.pkt);
        new_cmnh->ptype() = PT_GDSR;

        if(clusterh->route_repaired())
            goto  sendgratuitous;
        for (int i = 0; i < p.route.length(); i++)
        {
            if (p.route[i].addr == ntable->my_label)
            {
                printf("p.route[i].addr == ntable->my_label\n");
                clusterh->cur_addr() = i;
                break;
            }
        }
/*
        adjtable_ent *ent, *en;
        ent = ntable->GetAdjEntry(p.route[clusterh->cur_addr()+2].addr,1);
        en = ntable->GetAdjEntry(p.route[clusterh->cur_addr() + 3].addr,1);
        if(en)
        {
            clusterh->cur_addr()++;
            for(int i = clusterh->cur_addr(); i < clusterh->num_addrs() -1; i++)
            {
                clusterh->addrs()[i] = clusterh->addrs()[i + 2];
            }
            clusterh->num_addrs() -2;
        }
        else if(ent)
        {
            clusterh->cur_addr()++;
            for(int i = clusterh->cur_addr(); i < clusterh->num_addrs(); i++)
            {
                clusterh->addrs()[i] = clusterh->addrs()[i + 1];
            }
            clusterh->num_addrs()--;
        }
        else
        {
            return;
        }
 */
sendgratuitous:
        reply_table.insert(p.src,p.src,1);
        sendOutPacketWithRoute(p_copy, true);


       }



    }



  //  cmh->size() -= clusterh->size();
  //  clusterh->valid() = 0;
  //  cmh->size() -= IP_HDR_LEN;
    target_->recv(p.pkt, (Handler*)0);
    p.pkt = 0;
}



void GDSR_Agent::handleForwarding(GDSR_Packet& p)
{
    printf("In handleForwarding\n");
  /*
    if (route_cache->findRoute(p.dest, p.route, 1))
    {
        printf("Find the route to %i: %s in the cache\n", p.dest.getNSAddr_t(), p.route.dump());
    }
    printf("Current index: p.route.index() = %i\n ", p.route.index());
*/

    hdr_sr *clusterh = hdr_sr::access(p.pkt);
    hdr_cmn *cmh = HDR_CMN(p.pkt);

 printf("HDR_CMN(p.pkt)->size() = %i, gdsrh->size() = %i\n", HDR_CMN(p.pkt)->size(), clusterh->size());
    trace("gdsr %.9f _%s_ --- %d [%s -> %s] %s", Scheduler::instance().clock(), net_id.dump(), cmh->uid(), p.src.dump(), p.dest.dump(), clusterh->dump());


  //  assert(p.route[p.route.index()] == net_id || p.route[p.route.index()] == MAC_id);
/*
    if (p.route.index() >= p.route.length())
    {
        fprintf(stderr, "ran off the end of a  source route\n");
        trace("SDFU: ran off the end of a source route\n");
        drop(p.pkt, DROP_RTR_ROUTE_LOOP);
        p.pkt = 0;
        return;
    }
*/
    //change for pc
    if ((p.route.index() >= p.route.length()) && (!clusterh->route_reply()))
    {
        fprintf(stderr, "ran off the end of a  source route\n");
        trace("SDFU: ran off the end of a source route\n");
        drop(p.pkt, DROP_RTR_ROUTE_LOOP);
        p.pkt = 0;
        return;
    }


    if (gdsr_snoop_source_routes)
    {
        route_cache->noticeRouteUsed(p.route, Scheduler::instance().clock(), net_id);

    }

    struct hdr_cmn *ch = HDR_CMN(p.pkt);



        ch->size() -= clusterh->size();
        sendOutPacketWithRoute(p, false);
}

//void CLUSTER_Agent::sendOutPacketWithRoute(CLUSTER_Packet& p, bool fresh, Time delay = 0.0)
void GDSR_Agent::sendOutPacketWithRoute(GDSR_Packet& p, bool fresh, Time delay)
{
    printf("In sendOutPacketWithRoute of node %i\n", net_id.getNSAddr_t());
    hdr_sr *clusterh = hdr_sr::access(p.pkt);
    hdr_cmn *cmnh = HDR_CMN(p.pkt);
    hdr_ip *iph = HDR_IP(p.pkt);

    int differ = 0;
   printf("HDR_CMN(p.pkt)->size() = %i, gdsrh->size() = %i\n", HDR_CMN(p.pkt)->size(), clusterh->size());

    assert(clusterh->valid());
    assert(!clusterh->route_request());





    printf("Source route: %s\n",p.route.dump());

    if ((p.dest == net_id))
    {
        recv(p.pkt, (Handler*)0);
        p.pkt = 0;
        return;
    }

    if (fresh)
    {
        p.route.resetIterator();
        if(verbose_)
            trace("SO %.9f _%s_ originating %s, RREP ? %s", Scheduler::instance().clock(), net_id.dump(), p.route.dump(), clusterh->route_reply() ? "yes":"no");
    }

    p.route.fillSR(clusterh);
        cmnh->size() += clusterh->size();
       // assert((unsigned long)clusterh->addrs[clusterh->cur_addr()].addr == net_id.addr);

        printf("clusterh->cur_addr() = %i, p.route[clusterh->cur_addr()] = %i\n", clusterh->cur_addr(),p.route[clusterh->cur_addr()]);


        cmnh->next_hop() = -2;

        if(ntable->isNeighbor(p.dest.addr) || ntable->isNeighbor(iph->daddr()))
        {
            if(ntable->isNeighbor(p.dest.addr))
            {
                cmnh->next_hop() = p.dest.addr;
                clusterh->next_cluster() = p.dest.addr;
            }
            else
            {
                cmnh->next_hop() = iph->daddr();
                clusterh->next_cluster() = iph->daddr();
            }
            if(clusterh->route_reply())
            {
                if(clusterh->route_repaired() || clusterh->route_shortened())
                {
                   
                     goto done;
                    
                }
                else
                {

         
                     
                      if(ntable->my_label != (clusterh->reply_addrs()[clusterh->route_reply_len() -1]).addr)
                      {
                          (clusterh->reply_addrs()[clusterh->route_reply_len()]).addr = ntable->my_label;
                          (clusterh->reply_addrs()[clusterh->route_reply_len()]).addr_type = NS_AF_INET;
                          clusterh->route_reply_len()++;
                      }

                       int count = 0;
                    for(int i = clusterh->route_reply_len();i> 0; i--)
                    {
                        if(clusterh->reply_addrs()[i - 1].addr == ntable->my_label)
                        {
                            count++;
                        }
                    }

                    if(count > 1)
                    {
                        Packet::free(p.pkt);
                        return;
                    }
                }
            }
        }
        else
        {
            if(clusterh->route_reply())
            {
                if(clusterh->route_repaired() || clusterh->route_shortened())
                {
                    
                     goto done;

                }
                else
                {
                    Entry *e = request_table.getEntry(p.dest);
                    if(e)
                    {
                        cmnh->next_hop() = (e->nextnode).addr;
                    }
                    else
                    {
                        cmnh->next_hop() = ntable->my_label;
                    }


                    if(ntable->my_label != (clusterh->reply_addrs()[clusterh->route_reply_len() -1]).addr)
                     {
                      (clusterh->reply_addrs()[clusterh->route_reply_len()]).addr = ntable->my_label;
                      (clusterh->reply_addrs()[clusterh->route_reply_len()]).addr_type = NS_AF_INET;
                       clusterh->route_reply_len()++;
                     }


                    int count = 0;
                    for(int i = clusterh->route_reply_len();i> 0; i--)
                    {
                       if(clusterh->reply_addrs()[i - 1].addr == ntable->my_label)
                        {
                            count++;
                        }
                    }

                    if(count > 1)
                    {
                        Packet::free(p.pkt);
                        return;
                    }

                }
            }
            else
            {

                    if(p.route.member(ID(ntable->last_label,::IP),ID(ntable->last_label,::IP)) && (ntable->my_label != 255)
                            && (ntable->last_label != 255) && !(p.route.member(ID(ntable->my_label,::IP),ID(ntable->my_label,::IP))) && (ntable->last_label != iph->saddr()))
                    {
                         for (int i = 0; i < p.route.length(); i++)
                      {
                        if (p.route[i].addr == ntable->last_label)
                        {
                            printf("p.route[i].addr == ntable->last_label\n");
                            clusterh->cur_addr() = i;
                         //   if(net_id != ID(iph->saddr(),::IP))
                                clusterh->route_shortened() = 1;
                            break;
                        }
                      }

                        clusterh->addrs()[clusterh->cur_addr()].addr = ntable->my_label;
                        clusterh->addrs()[clusterh->cur_addr()].addr_type = NS_AF_INET;
                    }

                    p.route.fillSR(clusterh);
                    ::compressPath(p.route);


                
   

 done:          ntable_ent *en;
                adjtable_ent *ent;
                if(p.route.member(net_id,net_id))
                {
                    for (int i = 0; i < p.route.length(); i++)
                    {
                        if(p.route[i].addr == net_id.addr)
                        {
                            if((i < clusterh->cur_addr()) && (clusterh->cur_addr() < clusterh->num_addrs()))
                            {
                                break;
                            }
                            else
                            {
                            clusterh->cur_addr() = i;
                            break;
                            }
                        }
                    }
                }
                else
                {
                    for (int i = 0; i < p.route.length(); i++)
                    {
                        if(p.route[i].addr == ntable->my_label)
                        {
                             if((i < clusterh->cur_addr()) && (clusterh->cur_addr() < clusterh->num_addrs()))
                            {
                                break;
                            }
                            else
                            {
                            clusterh->cur_addr() = i;
                            break;
                            }
                        }
                    }
              //     if(net_id != ID(iph->saddr(),::IP))
              //         clusterh->route_shortened() = 1;
                }


                printf("clusterh->cur_addr() = %i, p.route[clusterh->cur_addr()] = %i\n",
                clusterh->cur_addr(),p.route[clusterh->cur_addr()]);




                if(cmnh->next_hop() == -2)
                {
                    if((ent = ntable->GetAdjEntry(iph->daddr(),1) ))
                    {

                        if(ent == ntable->GetAdjEntry(iph->daddr(),1))
                        {
                            clusterh->next_cluster() = iph->daddr();
                        }
                        goto choose_gateway;
                    }
                    else
                    {

                    if ((ent = ntable->GetAdjEntry(clusterh->addrs()[clusterh->cur_addr() + 2].addr,1)) && (clusterh->addrs()[clusterh->cur_addr()].addr == iph->saddr()) && (clusterh->cur_addr() < clusterh->num_addrs() -2))
            //        else if ((ent = ntable->GetAdjEntry(clusterh->addrs()[clusterh->cur_addr() + 2].addr,1)) && (clusterh->addrs()[clusterh->cur_addr()].addr == iph->saddr()))
                    {
                        clusterh->next_cluster() = clusterh->addrs()[clusterh->cur_addr() + 2].addr;
                        goto choose_gateway;
                    }
                    else if(en = ntable->GetEntry(clusterh->addrs()[clusterh->cur_addr() + 1].addr))
                  {
                    clusterh->next_cluster() = clusterh->addrs()[clusterh->cur_addr() + 1].addr;
                    cmnh->next_hop() = en->neighbor;
                   // clusterh->route_shortening() = 1;
                  }
                  else
                  {

                        
                    differ = clusterh->num_addrs() - 1 - clusterh->cur_addr();

                     while(differ > 1)
                     {
                         if (ent = ntable->GetAdjEntry(clusterh->addrs()[clusterh->cur_addr() + differ].addr,1))
                             break;
                         differ--;
                     }

                    if((ent = ntable->GetAdjEntry(clusterh->addrs()[clusterh->cur_addr() + differ].addr,1)) && (clusterh->cur_addr() < clusterh->num_addrs() - differ + 1))
                    {
                        if (differ > 1)
                        {
                            clusterh->route_shortened() = 1;
                            for (int i = clusterh->cur_addr() +1 ; i < clusterh->num_addrs() - differ + 1; i++)
                            {
                                clusterh->addrs()[i] = clusterh->addrs()[i + differ -1];
                            }
                            clusterh->num_addrs() = clusterh->num_addrs() - differ + 1;
                        }
                        clusterh->next_cluster() =  clusterh->addrs()[clusterh->cur_addr() + 1].addr;
                            printf("%i is in adjacent of %i\n",ent->neighbor_cluster,net_id.addr);
choose_gateway:              nexthop_ent *hop = ent->next_hop;
                              while(hop)
                             {
                                 if(hop->next_node_label == ent->neighbor_cluster)
                                 {
                                     en = ntable->GetEntry(hop->next_node);
                                     if(en)
                                     {
                                     cmnh->next_hop() = hop->next_node;
                                     break;
                                     }
                                 }
                                 hop = hop->next;
                             }

                            if(!hop)
                            {
                                hop = ent->next_hop;
                                while(hop)
                                {
                                    if(hop->next_node_label == ntable->my_label)
                                    {
                                        cmnh->next_hop() = hop->next_node;
                                        break;
                                    }
                                    hop = hop->next;
                                }
                            }


                            if(!hop)
                                cmnh->next_hop() = ent->next_hop->next_node;
                    }
                  }
                }
            }


               if(((cmnh->next_hop() == -2) && (net_id.addr != ntable->my_label)
                      && (ntable->my_label != 255) && (!clusterh->pass_clusterhead())))
                   cmnh->next_hop() = ntable->my_label;
            }
        }



        if(clusterh->route_error())
            GDSR_Agent::no_of_errors_++;
        trace("no_of_errors_ %i",GDSR_Agent::no_of_errors_++);
        trace("no_of_initiated_errors_ %i",GDSR_Agent::no_of_initiated_errors_);


           
          cmnh->direction() = hdr_cmn::DOWN;
         // if(!clusterh->route_reply() && !clusterh->route_error())
         if(!clusterh->route_reply())
          {
           cmnh->xmit_failure_ = GDSR_XmitFailureCallback;
           cmnh->xmit_failure_data_ = (void*)this;
          }

          cmnh->xmit_succeed_ = GDSR_XmitSucceedCallback;
          cmnh->xmit_succeed_data_ = (void*)this;

        
        cmnh->addr_type() = NS_AF_INET;

       
        printf("Packet will be sent to %i, next_cluster = %i\n", (int)cmnh->next_hop(),clusterh->next_cluster());




      if (ifq->prq_length() > 25)

          trace("SIFQ %.5f _%s_ len %d", Scheduler::instance().clock(), net_id.dump(), ifq->prq_length());



        int previous_state = iph->state();
         //add for pc

    printf("iph->node_id() =%i, iph->state() = %i\n", iph->node_id(), iph->state());
  iph->node_id() = net_id.getNSAddr_t();
  iph->state() = ntable->my_status;
  iph->clusterhead[0] = ntable->my_label;
  if(ntable->adjtable_size2 <= 5)
  {
      iph->num_adj_clusters() = ntable->adjtable_size2;
  }
  else
  {
      iph->num_adj_clusters() = 5;
  }

 //      if ((iph->state() == FULL_GW || iph->state() == DIST_GW))
  if(iph->num_adj_clusters())
  {
          adjtable_ent *e = ntable->adjtable_2;
          for (int i = 1; i <= ntable->adjtable_size2; i++)
          {
              if(i <= 5)
              {
                  while(e)
                  {
                      iph->clusterhead[i] = e->neighbor_cluster;
                      e = e->next;
                      break;
                  }
              }
              else
              {
                  break;
               }

          }

  }


    /*      if((cmnh->next_hop() == cmnh->prev_hop_) && )
        {
               xmitFailed(p.pkt,DROP_IFQ_QFULL);
               return;
        }

*/
      if((cmnh->next_hop() == -2) ||((cmnh->next_hop() == cmnh->prev_hop_) && (previous_state)) )
         {
           
                if (cmnh->next_hop() == -2)
                {
                    cmnh->next_hop() =  clusterh->addrs()[clusterh->cur_addr() + 1].addr;
                    clusterh->next_cluster() = clusterh->addrs()[clusterh->cur_addr() + 1].addr;
                }
                xmitFailed(p.pkt);
                return;
                  
         }

       

        cmnh->prev_hop_ = net_id.getNSAddr_t();


        
       Scheduler::instance().schedule(ll, p.pkt, delay);
    //  Scheduler::instance().schedule(ll,p.pkt, Random::uniform(0.0001) + delay);


    p.pkt = NULL;

    printf("After sendOutPacketWithRoute, clusterh->valid() = %i\n", clusterh->valid());
}



/*

void CLUSTER_Agent::getRouteForPacket(CLUSTER_Packet& p, bool retry)
{
    Entry *e = request_table.getEntry(p.dest);
    Time time = Scheduler::instance().clock();

    if (!retry)
    {
        p.pkt = 0;
    }

    CLUSTER_Packet rreq;
    rreq.dest = ID(0, ::IP);
    rreq.src = net_id;
    rreq.pkt = allocpkt();

    hdr_cluster *clusterh = hdr_cluster::access(rreq.pkt);
    hdr_ip *iph = HDR_IP(rreq.pkt);
    hdr_cmn *cmnh = HDR_CMN(rreq.pkt);

    iph->dport() = RT_PORT;
    //iph->src() = net_id.getNSAddr_t();
    iph->saddr() = net_id.getNSAddr_t();
    iph->sport() = RT_PORT;


    cmnh->ptype() = PT_CLUSTER;
    cmnh->num_forwards() = 0;
    cmnh->addr_type() = NS_AF_INET;

    clusterh->init();
    clusterh->route_request() = 1;
    clusterh->request_destination() = p.dest.getNSAddr_t();

    sendOutRtReq(rreq, MAX_SR_LEN);

}
*/


void GDSR_Agent::getRouteForPacket(GDSR_Packet& p, bool retry)
{
    printf("In getRouteForPacket of node %i\n",net_id.addr);
    Entry *e = request_table.getEntry(p.dest);
    Time time = Scheduler::instance().clock();

    int repaired = hdr_cbrp::access(p.pkt)->route_repaired();

    if (!retry)
    {
        stickPacketInSendBuffer(p);
        p.pkt = 0;

    }




    GDSR_Packet rreq;


  // rreq.dest = ID(0, ::IP);
   rreq.dest = p.dest;
    rreq.src = net_id;
    rreq.pkt = allocpkt();

    //printf("rreq.src = %u, %u\n", rreq.src.addr,rreq.src.getNSAddr_t() );
    //printf("rreq.dest = %u or %u\n", rreq.dest.addr, rreq.dest.getNSAddr_t());

    hdr_sr *clusterh = hdr_sr::access(rreq.pkt);
    hdr_ip *iph = HDR_IP(rreq.pkt);
    hdr_cmn *cmnh = HDR_CMN(rreq.pkt);

    iph->daddr() = Address::instance().create_ipaddr(p.dest.getNSAddr_t(), RT_PORT);
    iph->dport() = RT_PORT;
    //iph->src() = net_id.getNSAddr_t();
    //iph->saddr() = net_id.getNSAddr_t();
    iph->saddr() = Address::instance().create_ipaddr(net_id.getNSAddr_t(), RT_PORT);
    iph->sport() = RT_PORT;


    cmnh->ptype() = PT_GDSR;
    cmnh->num_forwards() = 0;
    cmnh->addr_type() = NS_AF_INET;
    cmnh->size() = size_ + IP_HDR_LEN;





    clusterh->init();
    clusterh->route_request() = 1;
//    clusterh->request_destination() = p.dest.getNSAddr_t();

    //add
    cmnh->prev_hop_ = net_id.addr;

    printf("In getroute: saddr() = %i, daddr() = %i\n",iph->saddr(), iph->daddr());

    if (BackOffTest(e, time))
    {
     e->last_type = UNLIMIT;
    // printf("Goto senOutRtReq\n");
    if(repaired)
     {
         iph->ttl_ = 3;
         sendOutRtReq(rreq,4);
     }
    else
         sendOutRtReq(rreq, MAX_SR_LEN);
    e->last_arp = time;
    }
    else if (LIMIT0 == e->last_type && (time -e->last_arp > gdsr_arp_timeout))
    {
        e->last_type = UNLIMIT;
        sendOutRtReq(rreq, MAX_SR_LEN);
    }
    else
    {
        if(!retry && verbose_srr)
            trace("SRR %.5f _%s_ RR-not-sent %s -> %s", Scheduler::instance().clock(), net_id.dump(), rreq.src.dump(), p.dest.dump());

        trace("gdsr %s -> %s, request entry rt_reqs_outstanding %d, last_rt_req %.9f", rreq.src.dump(), p.dest.dump(), e->rt_reqs_outstanding, e->last_rt_req);


        Packet::free(rreq.pkt);
        rreq.pkt = 0;
        return;
    }
// printf("After getRouteForPacket, clusterh->valid() = %i\n", clusterh->valid());
}





void GDSR_Agent::sendOutRtReq(GDSR_Packet& p, int max_prop)
{
    printf("In sendOutRtReq\n");
    hdr_sr *clusterh = hdr_sr::access(p.pkt);
    hdr_ip *iph = HDR_IP(p.pkt);
    hdr_cmn *cmnh = HDR_CMN(p.pkt);


    //add for pc

    printf("iph->node_id() =%i, iph->state() = %i\n", iph->node_id(), iph->state());
  iph->node_id() = net_id.getNSAddr_t();
  iph->state() = ntable->my_status;
  iph->clusterhead[0] = ntable->my_label;
  if(ntable->adjtable_size2 <= 5)
  {
      iph->num_adj_clusters() = ntable->adjtable_size2;
  }
  else
  {
      iph->num_adj_clusters() = 5;
  }

 // if ((iph->state() == FULL_GW || iph->state() == DIST_GW || iph->state() == ORDINARY_NODE || iph->state() == CLUSTER_HEAD))
 if(iph->num_adj_clusters())
  {
      adjtable_ent *e = ntable->adjtable_2;
      for (int i = 1; i <= ntable->adjtable_size2; i++)
      {
          if(i <= 5)
          {
              while(e)
              {
                  iph->clusterhead[i] = e->neighbor_cluster;
                  e = e->next;
                  break;
              }
          }
          else
          {
              break;
          }
      }

  }



    int i =0;
    assert(clusterh->valid());

    clusterh->rtreq_seq() = route_request_num++;
    clusterh->max_propagation() = max_prop;

    p.route.reset();


    if(gdsr_propagate_last_error && route_error_held && ((Scheduler::instance().clock() - route_error_data_time) < gdsr_max_err_hold))
    {
        assert(clusterh->num_route_errors() < MAX_ROUTE_ERRORS);
        clusterh->route_error() = 1;
        link_down *deadlink = &(clusterh->down_links()[clusterh->num_route_errors()]);
        deadlink->addr_type = NS_AF_INET;
        deadlink->from_addr = err_from.getNSAddr_t();
        deadlink->to_addr = err_to.getNSAddr_t();
        deadlink->tell_addr = GRAT_ROUTE_ERROR;
        clusterh->num_route_errors() += 1;

        if(max_prop > 0) route_error_held = false;
    }


    trace("GDSR %.5f _%s_ new-request %d %s #%d -> %d", Scheduler::instance().clock(), net_id.dump(), max_prop, p.src.dump(), clusterh->rtreq_seq(), p.dest.addr);

/*

    if (ntable->my_status == CLUSTER_HEAD)
    {

        p.route.appendToPath(net_id);

        fillGDSRPath(p.route, clusterh);

    }
    else
    {
        if(ntable->my_label != 255)
        {
            p.route.appendToPath(ID(ntable->my_label,::IP));
            fillGDSRPath(p.route,clusterh);
        }

    }
*/



    cmnh->next_hop() = MAC_BROADCAST;


   cmnh->direction() = hdr_cmn::DOWN;
/*
   for (int j = 0; j < clusterh->num_forwarders(); j++) {
    printf("num_forwarders() =  %i, forwarders[%i].which_gateway = %i, forwarders[%i].which_head = %i\n", clusterh->num_forwarders(), j, clusterh->forwarders[j].which_gateway, j, clusterh->forwarders[j].which_head);
   }
 */
   // iph->dst() = IP_BROADCAST;
   // iph->src() = myaddr_;
   // iph->daddr() = IP_BROADCAST;
  //  iph->dport() = RT_PORT;
  //  iph->saddr() = myaddr_;
  //  iph->sport() = RT_PORT;
 
   iph->saddr() = Address::instance().create_ipaddr(net_id.getNSAddr_t(), RT_PORT);
   iph->sport() = RT_PORT;
   iph->dport() = RT_PORT;



    cmnh->size() = clusterh->size();



    GDSR_Agent::no_of_initiated_rreqs_++;
    trace("no_of_initiated_rreqs_ %i\n",GDSR_Agent::no_of_initiated_rreqs_);
   /// Scheduler::instance().schedule(target_, p.pkt, 0.0);
    Scheduler::instance().schedule(ll, p.pkt, 0.0);
   // Scheduler::instance().schedule(ll,p.pkt,Random::uniform(0.01));
    p.pkt = NULL;

 printf("After sendOutRtReq, clusterh->valid() = %i\n", clusterh->valid());
}





void GDSR_Agent::handleRREQ(GDSR_Packet& p)
{
    printf("In handleRREQ\n");
    hdr_sr *clusterh = hdr_sr::access(p.pkt);
    hdr_ip *iph = HDR_IP(p.pkt);

     printf("HDR_CMN(p.pkt)->size() = %i, gdsrh->size() = %i\n", HDR_CMN(p.pkt)->size(), clusterh->size());

/*
    if (route_cache->findRoute(p.dest, p.route, 1))
    {
        printf("Find the route to %i: %s in the cache\n", p.dest.getNSAddr_t(), p.route.dump());
    }
     printf("Current index: p.route.index() = %i\n ", p.route.index());
*/

     printf("p.src.addr = %i, p.dest.addr = %i\n",p.src.addr,p.dest.addr);
    assert(clusterh->route_request());
  
        printf("iph->daddr() != IP_BROADCAST\n");
        // if (ntable->my_status == CLUSTER_HEAD || (iph->dst() == myaddr_))
        if ((ntable->my_status != ORDINARY_NODE) || ((ntable->my_status == ORDINARY_NODE) && (ntable->last_status == INITIAL_NODE)) || ((ntable->my_status == ORDINARY_NODE) && (ntable->isNeighbor(p.dest.addr))))
        {
           // printf("Goto Broadcast\n");
            BroadcastRREQ(p);
            if(ntable->my_status == ORDINARY_NODE) ntable->last_status = ORDINARY_NODE;
        }
        else
        {
            Packet::free(p.pkt);
             if((ntable->last_status == CLUSTER_HEAD) && (ntable->my_status != CLUSTER_HEAD))
            {

            Packet *packet = ntable->sendGiveUpPacket();
            Scheduler::instance().schedule(ll,packet,0.0);
       //     ntable->last_status = INITIAL_NODE;
            ntable->last_status = ORDINARY_NODE;

             }

            
        }

   
  p.pkt = NULL;

}


void GDSR_Agent::BroadcastRREQ(GDSR_Packet& p)
{
    printf("In BroadcastRREQ\n");
    hdr_sr *clusterh = hdr_sr::access(p.pkt);
    hdr_cmn *cmnh = HDR_CMN(p.pkt);
    hdr_ip *iph = HDR_IP(p.pkt);




    assert(clusterh->route_request());

    //add
    cmnh->prev_hop_ = net_id.addr;

    if (ignoreRouteRequest(p))
    {
        printf("The request from %i will be ignored\n", iph->saddr());

        if(verbose_srr)
            trace("gdsr %.5f _%s_ dropped %s #%d (ignored)", Scheduler::instance().clock(), net_id.dump(), p.src.dump(), clusterh->rtreq_seq());

        if((ntable->last_status == CLUSTER_HEAD) && (ntable->my_status != CLUSTER_HEAD))
        {
           
            Packet *packet = ntable->sendGiveUpPacket();
            Scheduler::instance().schedule(ll,packet,0.0);
         //   ntable->last_status = INITIAL_NODE;
            ntable->last_status = ORDINARY_NODE;
            
        }

        Packet::free(p.pkt);
        p.pkt = 0;
        return;
    }


    //request_table.insert(p.src, p.src, clusterh->rtreq_seq());
    //add
   // if (iph->node_id() != net_id.addr)
     request_table.insert(p.src,p.src,ID(iph->node_id(),::IP),clusterh->rtreq_seq());




    if (p.route.length() > (clusterh->max_propagation() /2))
    {

        if(verbose_srr)
            trace("gdsr %.5f _%s_ dropped %s #%d (prop limit exceeded)", Scheduler::instance().clock(), net_id.dump(), p.src.dump(), clusterh->rtreq_seq());

        Packet::free(p.pkt);
        p.pkt = 0;
        return;
    }

    if ((2*p.route.length()) > MAX_SR_LEN)
    {

        trace("gdsr %.5f _%s_ dropped %s #%d (SR full)", Scheduler::instance().clock(), net_id.dump(), p.src.dump(), clusterh->rtreq_seq());

        Packet::free(p.pkt);
        p.pkt = 0;
        return;
    }

   

 /*
    if(!(p.route.member(ID(ntable->my_label,::IP),ID(ntable->my_label,::IP))) && (ntable->my_label != 255))
    {
    p.route.appendToPath(net_id);
    fillGDSRPath(p.route, clusterh);
    }
*/
    cmnh->ptype() = PT_GDSR;
    cmnh->addr_type() = NS_AF_INET;
 // cmnh->addr_type() = NS_AF_ILINK;

        //add for pc

    printf("iph->node_id() =%i, iph->state() = %i\n", iph->node_id(), iph->state());
  iph->node_id() = net_id.getNSAddr_t();
  iph->state() = ntable->my_status;
  iph->clusterhead[0] = ntable->my_label;
 if(ntable->adjtable_size2 <= 5)
  {
      iph->num_adj_clusters() = ntable->adjtable_size2;
  }
  else
  {
      iph->num_adj_clusters() = 5;
  }

 // if ((iph->state() == FULL_GW || iph->state() == DIST_GW))
  if(iph->num_adj_clusters())
  {
      adjtable_ent *e = ntable->adjtable_2;
      for (int i = 1; i <= ntable->adjtable_size2; i++)
      {
          if( i <= 5)
          {
              while(e)
              {
                  iph->clusterhead[i] = e->neighbor_cluster;
                  e = e->next;
                  break;
              }
          }
          else
          {
              break;
          }
      }

  }

    if (ntable->isNeighbor(p.dest.addr))
    {
       // printf("ntable->isNeighbor(%i)\n", clusterh->request_destination());
        cmnh->next_hop() = p.dest.addr;
        //iph->dst() = clusterh->request_destination();
        iph->daddr() = p.dest.addr;
        
        cmnh->size() = clusterh->size();

        cmnh->direction() = hdr_cmn::DOWN;

        //add
        cmnh->prev_hop_ = net_id.addr;


        Scheduler &s = Scheduler::instance();
     //   s.schedule(target_, p.pkt, 0.0);
        s.schedule(ll, p.pkt, 0.0);
     //   p.pkt = NULL;
     //   s.schedule(ll,p.pkt,Random::uniform(0.001));
        return;

    }

#ifdef GDSR_DEBUG
      trace("gdsr RREQ %d: %s", myaddr_, ntable->printNeighbors());
#endif






    //if (cluster_reply_from_cache_on_propagating && replyFromRouteCache(p))
    if (gdsr_reply_from_cache_on_propagating && replyFromRouteCache(p))
    {
        p.pkt = NULL;
        return;
    }

    cmnh->next_hop() = MAC_BROADCAST;
    //iph->dst() = IP_BROADCAST;
   

   cmnh->direction() = hdr_cmn::DOWN;
    printf("Schedule to send packet\n");
    Scheduler::instance().schedule(ll,p.pkt,Random::uniform(0.01));




   // p_copy = NULL;
 //  Packet::free(p.pkt);
   // p.pkt = NULL;

    // printf("After BroadcastRREQ, clusterh->valid() = %i\n", clusterh->valid());
}

int GDSR_Agent::UnicastRREQ(GDSR_Packet& p, nsaddr_t nextcluster)
{
    printf("In UnicastRREQ of node %i\n", myaddr_);
    hdr_sr *clusterh = hdr_sr::access(p.pkt);
    hdr_cmn *cmnh = HDR_CMN(p.pkt);
    hdr_ip *iph = HDR_IP(p.pkt);

    cmnh->addr_type() = NS_AF_INET;
 // cmnh->addr_type() = NS_AF_ILINK;

    //add
    cmnh->prev_hop_ = net_id.addr;



    if (ntable->isNeighbor(p.dest.addr))
    {
        printf("ntable->isNeighbor(%i)\n", p.dest.addr);
        cmnh->next_hop() = p.dest.addr;




       // iph->dst() = clusterh->request_destination();
      //  iph->daddr() = clusterh->request_destination();
        iph->daddr() = Address::instance().create_ipaddr(p.dest.addr, RT_PORT);
        iph->dport() = RT_PORT;


        
      //  cmnh->size() += clusterh->size();
        cmnh->size() = clusterh->size();
         cmnh->direction() = hdr_cmn::DOWN;



        Scheduler &s = Scheduler::instance();
      //  s.schedule(target_, p.pkt, 0.0);
       s.schedule(ll, p.pkt, 0.0);

      // s.schedule(ll,p.pkt, Random::uniform(0.001));
        return 1;
    }

    //if (cluster_reply_from_cache_on_propagating && replyFromRouteCache(p))
    if (gdsr_reply_from_cache_on_propagating && replyFromRouteCache(p))
    {
        p.pkt = NULL;
        return 1;
    }

    adjtable_ent *en = ntable->GetAdjEntry(nextcluster,1);

    if (ntable->isNeighbor(nextcluster))
    {
        printf("nextcluster = %i, ntable->isNeighbor(%i)\n", nextcluster, nextcluster);
        cmnh->next_hop() = nextcluster;
        //iph->dst() = nextcluster;
        //iph->daddr() = nextcluster;
        iph->daddr() = Address::instance().create_ipaddr(nextcluster,RT_PORT);
        iph->dport() = RT_PORT;

    }
   // else if ((cmnh->next_hop() = ntable->GetNextNode(nextcluster, 1)))
    else if ((cmnh->next_hop() = en->next_hop->next_node) )
    {
       // printf("cmnh->next_hop() = ntable->GetNextNode(%i,1)\n", nextcluster);
        // iph->dst() = nextcluster;
       // iph->daddr() = nextcluster;
       iph->daddr() = Address::instance().create_ipaddr(nextcluster,RT_PORT);
       iph->dport() = RT_PORT;
    }
    else
    {

        trace("GDSR %.5f _%d_ drop-request: dropped (does not know how to reach next cluster %d), route(%s) clusterhead ? %s",
                Scheduler::instance().clock(), myaddr_, nextcluster, p.route.dump(), (ntable->my_status == CLUSTER_HEAD) ? "yes" : "no");

        Packet::free(p.pkt);
        p.pkt = NULL;
        return 0;
    }


 //  cmnh->xmit_failure_ = GDSR_XmitFailureCallback;
 // cmnh->xmit_failure_data_ = (void*)this;


   trace("gdsr %.5f _%s_ relay %s #%d -> %d %s to designated head %d via %d", Scheduler::instance().clock(), net_id.dump(),
   p.src.dump(), clusterh->rtreq_seq(), p.dest.addr, p.route.dump(), nextcluster, cmnh->next_hop());

  //  cmnh->size() += clusterh->size();
   cmnh->size() = clusterh->size();
     cmnh->direction() = hdr_cmn::DOWN;
  //  Scheduler::instance().schedule(target_, p.pkt, 0.0);
  //  Scheduler::instance().schedule(ll, p.pkt, 0.0);
    Scheduler::instance().schedule(ll,p.pkt,Random::uniform(0.01));
  //  p.pkt = NULL;

    return 1;
}



bool GDSR_Agent::ignoreRouteRequest(GDSR_Packet& p)
{
    printf("In ignoreRouteRequest\n");
    hdr_sr *clusterh = hdr_sr::access(p.pkt);
    if (request_table.get(p.src) >= clusterh->rtreq_seq())
    {
        return true;
    }
    if (p.route.member(net_id, MAC_id))
    {
        return true;
    }
    if (p.route.full())
    {
        return true;
    }
    return false;
}

void GDSR_Agent::fillGDSRPath(Path &path, hdr_sr *&clusterh)
{
    printf("Begin fillGDSRPath\n");
    for (int i = 0; i < path.length(); i++)
    {
        path[i].fillSRAddr(clusterh->addrs()[i]);
    }
    clusterh->num_addrs() = path.length();
    clusterh->cur_addr() = path.index();
}


static bool BackOffTest(Entry *e, Time time)
{
    Time next = ((Time) (0x1<<(e->rt_reqs_outstanding*2))) * gdsr_rt_rq_period;
    if (next > gdsr_rt_rq_max_period) next = gdsr_rt_rq_max_period;
    if (next + e->last_rt_req > time) return false;

    if (e->rt_reqs_outstanding < 15 ) e->rt_reqs_outstanding++;
    e->last_rt_req = time;
    return true;
}


int GDSR_Agent::handleRREP(GDSR_Packet& p)
{
    printf("In handleRREP of node %i\n",net_id.addr);

 /*
    if (route_cache->findRoute(p.dest, p.route, 1))
    {
        printf("Find the route to %i: %s in the cache\n", p.dest.getNSAddr_t(), p.route.dump());
    }
     printf("Current index: p.route.index() = %i\n ", p.route.index());
*/

    hdr_sr *clusterh = hdr_sr::access(p.pkt);
    hdr_cmn *cmnh = HDR_CMN(p.pkt);

 printf("HDR_CMN(p.pkt)->size() = %i, gdsrh->size() = %i\n", HDR_CMN(p.pkt)->size(), clusterh->size());

    cmnh->addr_type() = NS_AF_INET;
  //  cmnh->xmit_failure_ = GDSR_XmitFailureCallback;
  //  cmnh->xmit_failure_data_ = (void*)this;

   // cmnh->direction() = hdr_cmn::DOWN;

    if (p.route.length() <= 0)
    {
#ifdef GDSR_DEBUG
        printf("ERROR route len %d\n", p.route.length());
        printf("p.src %s, p.dest %s, me %s, route-reply %s \n", p.src.dump(), p.dest.dump(), net_id.dump(), return_reply_path(p.pkt, off_gdsr_));
#endif


        printf("p.route.length() <= 0\n");
        abort();
    }


    if ((clusterh->cur_addr() >= 0) && ( p.route[p.route.index()] == net_id) && (ntable->my_status == CLUSTER_HEAD))
    {
        printf("p.route[p.route.index()] == net_id && ntable->my_status == CLUSTER_HEAD\n");
        printf("clusterh->cur_addr() = %i\n", clusterh->cur_addr());
        clusterh->cur_addr()--;
        if (clusterh->cur_addr() < 0)
        {
            if (ntable->isNeighbor(p.dest.getNSAddr_t()))
            {
                printf("ntable->isNeighbor(%i)\n", p.dest.getNSAddr_t());
                cmnh->next_hop() = p.dest.getNSAddr_t();
            }
            else
            {
               // if (!(cmnh->next_hop() = ntable->GetNextNode(p.dest.getNSAddr_t(), 1)))
                if (!ntable->GetAdjEntry(p.dest.getNSAddr_t(),1))
                {
                    trace("GDSR %.5f _%d_ drop-reply-no-route unable return route to %s", Scheduler::instance().clock(),
                            myaddr_, p.dest.dump());

                    printf("Packet will be free\n");
                    Packet::free(p.pkt);
                    p.pkt = NULL;
                    return 0;
                }
            }



            cmnh->prev_hop_ = net_id.getNSAddr_t();
           // cmnh->size() += clusterh->size();
             cmnh->size() = clusterh->size();


            cmnh->direction() = hdr_cmn::DOWN;

           // Scheduler::instance().schedule(target_, p.pkt, 0);
          //  Scheduler::instance().schedule(ll, p.pkt, 0);
          //  p.pkt = NULL;


            if(net_id == p.src)
            {
                Scheduler::instance().schedule(ll,p.pkt,Random::uniform(0.01));
                return 1;
            }
            else
            {
                Scheduler::instance().schedule(ll, p.pkt, 0);
            }

            goto done;
        }
        nsaddr_t prev_cluster = clusterh->addrs()[clusterh->cur_addr()].addr;
        nsaddr_t next_node = (clusterh->reply_addrs()[clusterh->route_reply_len() -1 ]).addr;

        ntable_ent *en = ntable->GetEntry(prev_cluster);
        adjtable_ent *ent ;
        if (en == NULL)
        {
           /// printf("ent = ntable->GetAdjEntry(prev_cluster, 1) == NULL\n");
            ent = ntable->GetAdjEntry(prev_cluster, 1);
        }
        if (ent == NULL)
        {

            trace("GDSR %.5f _%s_ drop-reply-no-route #%d (route reply %s -> %s cannot reach prev cluster %d on route %s) previous hop %d",
                    Scheduler::instance().clock(), net_id.dump(), clusterh->rtreq_seq(), p.src.dump(), p.dest.dump(), prev_cluster, p.route.dump(), cmnh->prev_hop_);

            //  printf("ent = ntable->GetAdjEntry(prev_cluster, 0) == NULL \n");
            Packet::free(p.pkt);
            p.pkt = NULL;
            return 0;
        }

        nexthop_ent *next_hop = ent->next_hop;
        assert(next_hop != NULL);

        while(next_hop)
        {

            next_hop = next_hop->next;
        }


        if (next_hop == NULL)
        {
            printf("next_hop = NULL\n");
            cmnh->next_hop() = ent->next_hop->next_node;
           // assert(cmnh->next_hop() > 0);

           (clusterh->reply_addrs()[clusterh->route_reply_len()]).addr = net_id.addr;
           (clusterh->reply_addrs()[clusterh->route_reply_len()]).addr_type = NS_AF_INET;
           clusterh->route_reply_len()++;

        }
       // cmnh->size() += clusterh->size();
        cmnh->size() = clusterh->size();
        cmnh->prev_hop_ = net_id.getNSAddr_t();

       cmnh->direction() = hdr_cmn::DOWN;
      // Scheduler::instance().schedule(target_, p.pkt, 0);
      //    Scheduler::instance().schedule(ll, p.pkt, 0.0);
     //  Scheduler::instance().schedule(ll,p.pkt,Random::uniform(0.01) );
      // p.pkt = NULL;
        if(net_id == p.src)
            {
                Scheduler::instance().schedule(ll,p.pkt,Random::uniform(0.01));
                return 1;
            }
            else
            {
                Scheduler::instance().schedule(ll, p.pkt, 0);
            }




     //   hdr_ip *iph = HDR_IP(p.pkt);
   /*    printf("clusterh->route_reply_len() = %i\n", clusterh->route_reply_len());
       printf("iph->saddr() = %i, iph->daddr() = %i, iph->ttl() = %i\n", iph->saddr(), iph->daddr(), iph->ttl());
      printf("clusterh->num_addr() = %i\n", clusterh->num_addrs());
    for (int i = 0; i < clusterh->num_addrs(); i++)
    {
        printf("p.route[%i] = %i\n",i, p.route[i].getNSAddr_t());
    }
*/


    }
    else
    {
         printf("net_id.addr = %i\n",net_id.addr);
        printf("!p.route[p.route.index()] == net_id || ! ntable->my_status == CLUSTER_HEAD\n");

        nsaddr_t next_cluster;
        cmnh->addr_type() = NS_AF_INET;

        if (clusterh->cur_addr() < 0)
        {
            next_cluster = p.dest.addr;
            if (ntable->isNeighbor(next_cluster))
            {
                printf("ntable->isNeighbor(%i)\n", next_cluster);
                cmnh->next_hop() = next_cluster;
            }
            else
            {
                adjtable_ent *ent = ntable->GetAdjEntry(next_cluster,1);
                // cmnh->next_hop() = ntable->GetNextNode(next_cluster, 1);
                cmnh->next_hop() = ent->next_hop->next_node;
                if (!cmnh->next_hop())
                {
                    trace("GDSR %.5f _%d_ drop-reply-no-route %s -> %s #%d (route reply cannot reach prev cluster %d)",
                            Scheduler::instance().clock(), myaddr_, p.src.dump(), p.dest.dump(), clusterh->rtreq_seq(), next_cluster);


                    // printf("!cmnh->next_hop()\n");
                    Packet::free(p.pkt);
                    p.pkt = 0;
                    return 0;
                }

            }
        }
        else
        {
            next_cluster = clusterh->addrs()[clusterh->cur_addr()].addr;
            printf("next_cluster = %i\n",next_cluster);
            if (ntable->isNeighbor(next_cluster))
            {
                printf("ntable->isNeighobr(%i)\n", next_cluster);
                cmnh->next_hop() = next_cluster;
            }
            else
            {
                adjtable_ent *ent = ntable->GetAdjEntry(next_cluster,1);
                 cmnh->next_hop() = ent->next_hop->next_node;
                   if (!cmnh->next_hop())
                   {
                       trace("GDSR %.5f _%d_ drop-reply-no-route %s->%s #%d(route reply cannot reach prev cluster %d)",
                               Scheduler::instance().clock(), myaddr_, p.src.dump(), p.dest.dump(), clusterh->rtreq_seq(), next_cluster);

                       // printf("!cmnh->next_hop()\n");
                       Packet::free(p.pkt);
                       p.pkt = 0;
                       return 0;
                   }

            }
        }
        int i;
        for (i = clusterh->route_reply_len(); i > 0; i--)
        {
            if (clusterh->reply_addrs()[i-1].addr == cmnh->next_hop())
            {
                printf("%i == cmnh->next_hop()\n", clusterh->reply_addrs()[i-1].addr);
                break;
            }
        }
        if (i > 0)
        {
            trace("GDSR %.5f _%d_ drop-reply-looped %s->%s #%d existing route: %s reaching next cluster %d via %d",
                    Scheduler::instance().clock(), myaddr_, p.src.dump(), p.dest.dump(), clusterh->rtreq_seq(), p.route.dump(),
                    next_cluster, cmnh->next_hop());
            // printf("i >0\n");
            Packet::free(p.pkt);
            p.pkt = 0;
            return 0;
        }
      //  printf("Schedule to send RREP\n");
     //   hdr_ip *iph = HDR_IP(p.pkt);
      //  printf("iph->saddr() = %i, iph->daddr() = %i\n", iph->saddr(), iph->daddr());
      //  printf("clusterh->request_destination() = %i\n", clusterh->request_destination());

        (clusterh->reply_addrs()[clusterh->route_reply_len()]).addr = net_id.addr;
        (clusterh->reply_addrs()[clusterh->route_reply_len()]).addr_type = NS_AF_INET;
        clusterh->route_reply_len()++;

        cmnh->prev_hop_ = net_id.getNSAddr_t();
       // cmnh->size() += clusterh->size();
        cmnh->size() = clusterh->size();
         cmnh->direction() = hdr_cmn::DOWN;
 //Scheduler::instance().schedule(target_, p.pkt, 0);
    //   Scheduler::instance().schedule(ll, p.pkt, 0);
         //Scheduler::instance().schedule(ll, p.pkt, Random::uniform(0.01));

          if(net_id == p.src)
            {
                Scheduler::instance().schedule(ll,p.pkt,Random::uniform(0.01));
                return 1;
            }
            else
            {
                Scheduler::instance().schedule(ll, p.pkt, 0);
            }

       //  p.pkt = NULL;

         printf("clusterh->num_addr() = %i\n", clusterh->num_addrs());
    for (int i = 0; i < clusterh->num_addrs(); i++)
    {
        printf("p.route[%i] = %i\n",i, p.route[i].getNSAddr_t());
    }
         printf("cmnh->nex_hop() = %i\n", cmnh->next_hop());


         Path reply_route(clusterh->reply_addrs(), clusterh->route_reply_len());
         for (int j = 0; j < reply_route.length() -1; j ++)
    {
        printf(" reply_route[%i] = %i\n", j, reply_route[j].getNSAddr_t());
    }


    }

    done:

#ifdef GDSR_DEBUG
                    trace("gdsr _%d_ route-reply-sent %s #%d -> %s, next hop %d to reach %d, rest of recorded clusterheads %s, constructed return path %s",
                    myaddr_, p.src.dump(), clusterh->rtreq_seq(), p.dest.dump(), cmnh->next_hop(), (clusterh->cur_addr() > -1) ? clusterh->addrs[clusterh->cur_addr()].addr : iph->daddr(),
                    p.route.dump(), return_reply_path(p.pkt, off_gdsr_));
#endif


    p.pkt = NULL;
    return 1;
}


void GDSR_Agent::acceptRREP(GDSR_Packet& p)
{

    hdr_sr *clusterh = hdr_sr::access(p.pkt);
    printf("In acceptRREP\n");
  /*  for (int k = 0; k < clusterh->num_addrs(); k++)
    {
    printf("p.route[%i].addr = %i\n",k, p.route[k].getNSAddr_t());
    }
    */
     for (int k = 0; k < p.route.length(); k++)
    {
    printf("p.route[%i].addr = %i\n",k, p.route[k].getNSAddr_t());
    }

    for (int k = 0; k < clusterh->route_reply_len(); k++)
    {
        printf("clusterh->reply_addrs()[%i] = %i\n",  k, (int)clusterh->reply_addrs()[k].addr);
    }


    if(clusterh->route_repaired())
    {
        trace("GDSR %.5f _%d_ grat-reply-repair from %d, route %s",
                Scheduler::instance().clock(), myaddr_, p.src.addr, p.route.dump());
    }
    else if (clusterh->route_shortened())
    {
        trace("GDSR %.5f _%d_ grat-reply-shorten from %d, route %s", Scheduler::instance().clock(),
                myaddr_, p.src.addr, p.route.dump());
    }
    else
    {
        trace("GDSR %.5f _%d_ reply-received from %d, route %s", Scheduler::instance().clock(),
                myaddr_, p.src.addr, p.route.dump());
    }



    if(!clusterh->route_reply())
    {
        trace("SDFU non route containing packet given to acceptRREP");
        fprintf(stderr, "dfu: non route containing packet given to acceptRREP\n");

        //add
        return;
    }


 /*   if(clusterh->route_reply() && !clusterh->route_repaired() && !clusterh->route_shortening())
    {
    p.route.appendToPath(net_id);
  //  fillGDSRPath(p.route, clusterh);
    p.route.fillSR(clusterh);
    }
*/

    
    if((ntable->my_label != clusterh->reply_addrs()[clusterh->route_reply_len() -1].addr) && (ntable->my_label != 255))
    {

       (clusterh->reply_addrs()[clusterh->route_reply_len()]).addr = ntable->my_label;
        (clusterh->reply_addrs()[clusterh->route_reply_len()]).addr_type = NS_AF_INET;
        clusterh->route_reply_len()++;
    }

    if(net_id != clusterh->reply_addrs()[clusterh->route_reply_len() -1])
    {

       (clusterh->reply_addrs()[clusterh->route_reply_len()]).addr = net_id.addr;
        (clusterh->reply_addrs()[clusterh->route_reply_len()]).addr_type = NS_AF_INET;
        clusterh->route_reply_len()++;
    }

   // clusterh->cur_addr() = clusterh->route_reply_len() -1;

    


    Path reverse_reply_route(clusterh->reply_addrs(),clusterh->route_reply_len());

  /* if(net_id != clusterh->reply_addrs()[clusterh->route_reply_len() -1])
    {

        reverse_reply_route.appendToPath(net_id);
    }
*/
   // ::compressPath(reverse_reply_route);

    ::compressPath(reverse_reply_route);
 //    Path reply_route = reverse_reply_route.reverse();
    Path reply_route;
    if(!clusterh->route_repaired() && !clusterh->route_shortened())
    {

        reply_route = reverse_reply_route.reverse();
    }
    else
    {
        Path reverse_reply(clusterh->addrs(), clusterh->num_addrs());
        reply_route = reverse_reply.reverse();
    }






   // reply_route.reverseInPlace();
  //  reply_route.resetIterator();


    printf("clusterh->request_destination() =  %i\n", p.dest.addr);
    hdr_ip *iph = HDR_IP(p.pkt);
    printf("iph->saddr() = %i, iph->daddr() = %i\n", iph->saddr(), iph->daddr());





    bool good_reply = true;
    for (int i = 0; i < reply_route.length() -1; i++)
        if (God::instance()->hops(reply_route[i].getNSAddr_t(), reply_route[i+1].getNSAddr_t()) != 1)
        {
            printf("This reply is not valid\n");
            good_reply = false;
            break;
        }

#ifdef GDSR_DEBUG
    trace("gdsr %.9f _%s_ reply-received %d from %s %s #%d -> %s %s",
    Scheduler::instance().clock(), net_id.dump(), good_reply ? 1 : 0, p.src.dump(), reply_route[0].dump(),
    clusterh->rtreq_seq(), reply_route[reply_route.length() -1].dump(), reply_route.dump());
#endif


    for (int j = 0; j < reply_route.length(); j ++)
    {
        printf(" reply_route[%i] = %i\n", j, reply_route[j].getNSAddr_t());
    }


    printf("net_id = %i, MAC_id =  %i\n", (int)net_id.addr, (int)MAC_id.addr);
/*    if(clusterh->route_reply() && !clusterh->route_repaired() && !clusterh->route_shortening())
    {
       p.route.reverseInPlace();
       route_cache->addRoute(p.route,Scheduler::instance().clock(),net_id);
   printf("Route cache 1: %s\n", p.route.dump());
    }
 */
    route_cache->addRoute(reply_route, Scheduler::instance().clock(), p.src);
    printf("Route cache 2: %s\n", reply_route.dump());



        Entry *e = request_table.getEntry(reply_route[reply_route.length() -1]);
        e->rt_reqs_outstanding = 0;
        e->last_rt_req = 0.0;

        Time delay = 0.0;
        for (int c = 0; c < SEND_BUF_SIZE; c++)
        {


        //    for (int i = 0; (i < clusterh->num_addrs()) && (send_buf[c].p.dest.addr); i++)
         //   {
         //       printf("send_buf[%i].p.route[%i].addr =  %i\n",c, i, send_buf[c].p.route[i].getNSAddr_t());
         //   }
            if (send_buf[c].p.pkt == NULL)
            {
             // printf("send_buf[%i].p.pkt is NULL\n", c);
                continue;
            }

         /*
            if (send_buf[c].p.pkt)
            {
                printf("send_buf[%i].p.dest.addr = %i, send_buf[%i].p.route.dump() = %s\n",c,send_buf[c].p.dest.getNSAddr_t(),c,send_buf[c].p.route.dump()  );
            }

*/


            if (route_cache->findRoute(send_buf[c].p.dest, send_buf[c].p.route, 1))
            {

#ifdef GDSR_DEBUG



                printf("We find the route\n");
                printf("route_cache->findRoute(send_buf[c].p.dest, send_buf[c].p.route,1)\n");
                struct hdr_cmn *ch = HDR_CMN(send_buf[c].p.pkt);
                if (ch->size() < 0)
                {
                    drop(send_buf[c].p.pkt , "XXX");
                    abort();
                }

#endif

                if(verbose_)
                    trace("Sdebug %.9f _%s_ liberated from sendbuf %s-> %s %s",
                            Scheduler::instance().clock(), net_id.dump(), send_buf[c].p.src.dump(),
                            send_buf[c].p.dest.dump(), send_buf[c].p.route.dump());

                sendOutPacketWithRoute(send_buf[c].p, true, delay);
                delay += gdsr_arp_timeout;
                send_buf[c].p.pkt = NULL;
            }
        }

}



void GDSR_Agent::returnSrcRouteToRequestor(GDSR_Packet& p)
{
    printf("In returnSrcRouteToRequestor of node %i\n",net_id.addr);
    hdr_sr *old_clusterh = hdr_sr::access(p.pkt);

    if (p.route.full()) return;

    GDSR_Packet p_copy = p;
    p_copy.pkt = allocpkt();
    p_copy.dest = p.src;

    hdr_ip *new_iph = HDR_IP(p_copy.pkt);
    hdr_sr *new_clusterh = hdr_sr::access(p_copy.pkt);
    hdr_cmn *new_cmnh = HDR_CMN(p_copy.pkt);




   // new_cmnh->size() = IP_HDR_LEN;

    trace("GDSR %.5f _%s_ reply-sent %s -> %d %s", Scheduler::instance().clock(),net_id.dump(), p.src.dump(),
    p.dest.addr, p.route.dump());


   // assert(old_clusterh->request_destination() == net_id.getNSAddr_t());
    printf("old_clusterh->request_destination() = %i\n", net_id.getNSAddr_t());
    p_copy.src = net_id;

    printf("p_copy.src.addr =  %i, p_copy.dst.addr = %i\n",(int) p_copy.src.addr,(int) p_copy.dest.addr);

//addd
  //  if(p_copy.src == p_copy.dest)
   //     return;

    /*
    if (!p.route.member(ID(ntable->my_label,::IP),ID(ntable->my_label,::IP)))
    {
        p_copy.route.appendToPath(ID(ntable->my_label,::IP));
    }
   */

  //  p_copy.route.appendToPath(net_id);
 new_clusterh->init();
    new_clusterh->route_reply() = 1;
   
  //  for (int i = 0; i < p_copy.route.length(); i++)
  //  {
  //      p_copy.route[i].fillSRAddr(new_clusterh->reply_addrs()[i]);
  //      new_clusterh->route_reply_len() = p_copy.route.length();
 //  }

 /*   new_clusterh->route_shortened() = old_clusterh->route_shortened();

    if(!new_clusterh->route_shortened())
    {
        new_clusterh->reply_addrs()[0].addr = net_id.addr;
        new_clusterh->reply_addrs()[0].addr_type = NS_AF_INET;
        new_clusterh->route_reply_len() = 1;
    }
    else
    {
        new_clusterh->reply_addrs()[0].addr = ntable->my_label;
        new_clusterh->reply_addrs()[0].addr_type = NS_AF_INET;
        new_clusterh->route_reply_len() = 1;
    }
*/

    p_copy.route.appendToPath(net_id);

   // new_clusterh->reply_addrs()[0].addr = ntable->my_label;
    new_clusterh->reply_addrs()[0].addr = net_id.addr;
    new_clusterh->reply_addrs()[0].addr_type = NS_AF_INET;
    new_clusterh->route_reply_len() = 1;


    if((new_clusterh->reply_addrs()[0].addr != ntable->my_label) && (ntable->my_label != 255))
    {
    new_clusterh->reply_addrs()[1].addr = ntable->my_label;
    new_clusterh->reply_addrs()[1].addr_type = NS_AF_INET;
    new_clusterh->route_reply_len() = 2;
    }

   // new_iph->daddr() = p_copy.dest.addr;
    new_iph->daddr() = Address::instance().create_ipaddr(p_copy.dest.getNSAddr_t(),RT_PORT);

    new_iph->dport() = RT_PORT;

   // new_iph->saddr() = p_copy.src.addr;
    new_iph->saddr() =
    Address::instance().create_ipaddr(p_copy.src.getNSAddr_t(),RT_PORT);


    new_iph->sport() = RT_PORT;
    new_iph->ttl() =  255;







    new_clusterh->rtreq_seq() = old_clusterh->rtreq_seq();
    new_cmnh->ptype() = PT_GDSR;
    new_cmnh->size() = IP_HDR_LEN;



  //  p_copy.route.reverseInPlace();

    p_copy.route.resetIterator();
   // fillGDSRPath(p_copy.route,new_clusterh);
    p.route.fillSR(new_clusterh);

    new_cmnh->size() += new_clusterh->size();
    new_cmnh->next_hop() = HDR_IP(p.pkt)->node_id();


    printf("saddr() = %i, daddr() = %i\n", new_iph->saddr(), new_iph->daddr());
    printf("new_clusterh->num_addr() = %i, p_copy.route.index() = %i, new_clusterh->cur_addr() = %i\n", new_clusterh->num_addrs(), p_copy.route.index(),new_clusterh->cur_addr());
    for (int i = 0; i < new_clusterh->num_addrs(); i++)
    {
        printf("p.route[%i] = %i\n",i, p_copy.route[i].getNSAddr_t());
    }

     // new_cmnh->direction() = hdr_cmn::DOWN;
    Scheduler::instance().schedule(this,p_copy.pkt,Random::uniform(0.01));
   // Scheduler::instance().schedule(this,p_copy.pkt,Random::uniform(0.1));
    // Scheduler::instance().schedule(this,p_copy.pkt,0.0);




}

bool GDSR_Agent::replyFromRouteCache(GDSR_Packet& p)
{
    Path rest_of_route;

    hdr_sr *old_clusterh = hdr_sr::access(p.pkt);
    p.dest = ID(p.dest.addr, ::IP);

    if (!route_cache->findRoute(p.dest, rest_of_route, 0))
    {
        return false;
    }

    assert(rest_of_route[0] == net_id || rest_of_route[0] == MAC_id);

    if (rest_of_route.length() + 2 * p.route.length() > MAX_SR_LEN) return false;

    hdr_sr *clusterh = hdr_sr::access(p.pkt);
    int request_seqnum = clusterh->rtreq_seq();

    Packet *rrp = allocpkt();

    hdr_ip *iph = HDR_IP(rrp);
  //  iph->saddr() = myaddr_;
    iph->saddr() = Address::instance().create_ipaddr(net_id.getNSAddr_t(),RT_PORT);
    iph->sport() = RT_PORT;
    //iph->daddr() = p.src.addr;
   // iph->daddr() = p.src.getNSAddr_t();
    iph->daddr() = Address::instance().create_ipaddr(p.src.getNSAddr_t(),RT_PORT);
    iph->dport() = RT_PORT;
    iph->ttl() = 255;

    clusterh = hdr_sr::access(rrp);
    clusterh->init();

    clusterh->route_reply() = 1;

    int len = rest_of_route.length();
    for (int i = 0; i < len; i++)
        rest_of_route[len - i - 1].fillSRAddr(clusterh->reply_addrs()[i]);
    clusterh->route_reply_len() = len;

    clusterh->rtreq_seq() = request_seqnum;

    hdr_cmn *cmnh = hdr_cmn::access(rrp);
    cmnh->ptype() = PT_GDSR;


//    fillGDSRPath(p.route, clusterh);
    p.route.fillSR(clusterh);
    //  cmnh->size() = IP_HDR_LEN + clusterh->size();
    cmnh->size() = clusterh->size();

    clusterh->cur_addr() = clusterh->num_addrs() - 1;

    nsaddr_t next_cluster;

    if (clusterh->cur_addr() >= 0)
    {
        next_cluster = clusterh->addrs()[clusterh->cur_addr()].addr;

    }
    else
    {
        next_cluster = iph->daddr();
    }

    adjtable_ent *adj_ent;
    adjtable_ent *en = ntable->GetAdjEntry(next_cluster,1);
   // if ((cmnh->next_hop() = ntable->GetNextNode(next_cluster, 1)))
     if ((cmnh->next_hop() = en->next_hop->next_node) )
    {
        goto DONE;
    }
    else if ((adj_ent = ntable->GetAdjEntry(next_cluster, 0)))
    {
        cmnh->next_hop() = adj_ent->next_hop->next_node;
        goto DONE;
    }
    else
    {
        Packet::free(rrp);
        return false;
    }

    DONE:
   // Scheduler::instance().schedule(target_, rrp, 0);
    Scheduler::instance().schedule(ll, rrp, 0);

    trace("GDSR %.9f _%s_ cache-reply-sent %d -> %d #%d (len %d) %s", Scheduler::instance().clock(),net_id.dump(),
    iph->saddr(), iph->daddr(), request_seqnum, rest_of_route.length(), rest_of_route.dump());


  //  Packet::free(p.pkt);
    p.pkt = NULL;
    return true;

}


void
GDSR_Agent::xmitFailed(Packet *pkt, const char* reason)
{
    printf("In xmitFailed of  node %i\n", net_id.addr);
    hdr_sr *gdsrh = hdr_sr::access(pkt);
    hdr_ip *iph = HDR_IP(pkt);
    hdr_cmn *cmh = HDR_CMN(pkt);

    ID tell_id;
    ID from_id;
    ID to_id;

    printf("saddr() = %i, daddr() = %i, net_id.addr() =  %i, next_hop = %i\n",iph->saddr(),iph->daddr(),net_id.addr,cmh->next_hop());
    assert(cmh->size() >= 0);

    if(verbose_)
        trace("SSendFailure %.9f _%s_ --- %d - %s, (to %d) RREQ %d (%d, %d), RREP %d", Scheduler::instance().clock(),
                net_id.dump(), cmh->uid(),gdsrh->dump(),iph->daddr(), iph->saddr(), gdsrh->rtreq_seq(), gdsrh->route_reply());


    if(net_id.addr == cmh->next_hop())
    {
        Packet::free(pkt);
        return;
    }



    if((net_id.addr == iph->saddr()) && (gdsrh->addrs()[gdsrh->cur_addr() +2].addr == gdsrh->next_cluster()))
    {
       route_cache->noticeDeadLink(ID(gdsrh->addrs()[gdsrh->cur_addr() +1].addr, ::IP), ID(gdsrh->addrs()[gdsrh->cur_addr() +2].addr, ::IP), Scheduler::instance().clock());
    }


    if((gdsrh->addrs()[gdsrh->cur_addr() +1].addr != gdsrh->next_cluster()) && (gdsrh->next_cluster() != ntable->my_label))
    {
       route_cache->noticeDeadLink(ID(gdsrh->addrs()[gdsrh->cur_addr()].addr, ::IP), ID(gdsrh->addrs()[gdsrh->cur_addr() +1].addr, ::IP), Scheduler::instance().clock());
    }
    



    ntable_ent *ent;

    if(ent = ntable->GetEntry(cmh->next_hop()))
    {
#ifdef GDSR_DEBUG
        trace("gdsr _%d_ delete %d from neighbor table last update %.9f", myaddr_, cmh->next_hop(), ent->last_update);
#endif

        if(ent->neighbor_status == CLUSTER_HEAD)
        {
            ntable->DeleteNeighborCluster(cmh->next_hop(), 0);
            ntable->DeleteNeighborCluster(cmh->next_hop(),1);
        }
        ntable->DeleteEntry(cmh->next_hop());
        ntable->DeleteAdjEntry(cmh->next_hop(),1);
        ntable->DeleteAdjEntry(cmh->next_hop(),0);
      //  ntable->DeleteNextnodeToNextCluster(gdsrh->next_cluster(), cmh->next_hop(), 1);
     //   ntable->DeleteNextnodeToNextCluster(gdsrh->next_cluster(), cmh->next_hop(), 0);


    }


    if(gdsrh->route_reply() && (gdsrh->route_repaired() || (gdsrh->route_shortened())))
    {
        Packet::free(pkt);
        return;
    }

   


    from_id = net_id;
    to_id.addr = cmh->next_hop();
    to_id.type = (ID_Type)NS_AF_INET;




    if(!gdsrh->route_request() && !gdsrh->route_reply() && !gdsrh->route_repaired())
    {
        tell_id.addr = gdsrh->addrs()[0].addr;
        tell_id.type = (ID_Type)NS_AF_INET;
    }


    printf("saddr() = %i, daddr() = %i, from_id = %i, to_id = %i, tell_id = %i \n", iph->saddr(),iph->daddr(),from_id.addr,to_id.addr,tell_id.addr);

 /*
   //change
   from_id.addr = gdsrh->addrs[gdsrh->cur_addr()].addr;
   from_id.type = (ID_Type)NS_AF_INET;
   to_id.addr = gdsrh->addrs[gdsrh->cur_addr() +1].addr;
   to_id.type = (ID_Type)NS_AF_INET;
    tell_id.addr = gdsrh->addrs[0].addr;
        tell_id.type = (ID_Type)NS_AF_INET;
*/




#ifdef USE_GOD_FEEDBACK
    if(God::instance()->hops(from_id.getNSAddr_t(), to_id.getNSAddr_t()) == 1)
    {
        linkerr_is_wrong++;
        trace("SxmitFailed %.5f _%s_ %d -> %d god okays #%d", Scheduler::instance().clock(),
        net_id.dump(), from_id.getNSAddr_t(), to_id.getNSAddr_t(), linkerr_is_wrong);
        fprintf(stderr, "xmitFailed on link %d -> %d god okays - ignoring & recycling #%d\n",from_id.getNSAddr_t(),
        to_id.getNSAddr_t(), linkerr_is_wrong);

        assert(p.pkt->incoming == 0);
        ll->recv(pkt, (Handler*)0);
        return;
    }
#endif

    int salvage = 0;

    if(strcmp(reason,"DROP_IFQ_FULL") != 0)
    {
         route_cache->noticeDeadLink(from_id, to_id, Scheduler::instance().clock());
         route_cache->noticeDeadLink(from_id, ID(gdsrh->next_cluster(), ::IP), Scheduler::instance().clock());
          salvage = undeliverablePkt(pkt->copy(),1);


     {
	    Packet *r, *nr, *queue1 = 0, *queue2 = 0;
	    // pkts to be recycled

	    while((r = ifq->prq_get_nexthop(to_id.getNSAddr_t()))) {
	      r->next_ = queue1;
	      queue1 = r;
	    }

	    // the packets are now in the reverse order of how they
	    // appeared in the IFQ so reverse them again
	    for(r = queue1; r; r = nr) {
	      nr = r->next_;
	      r->next_ = queue2;
	      queue2 = r;
	    }

	    // now process them in order
	    for(r = queue2; r; r = nr) {
	      nr = r->next_;
	      undeliverablePkt(r, 1);
	    }
	  }

    }


    if(tell_id == net_id || tell_id == MAC_id)
    {
        if(verbose_)
            trace("Sdebug _%s_ not bothering to send route error to myself", tell_id.dump());

        Packet::free(pkt);
        pkt = 0;
        return;
    }

    printf("Condition (tell_id == net_id || tell_id == MAC_id) is not satisfied\n");


  // if(gdsrh->route_request() || (gdsrh->route_reply()) || gdsrh->route_repaired() || gdsrh->route_shortening())
/*    if(gdsrh->route_request() || (gdsrh->route_reply()) || gdsrh->route_repaired() || gdsrh->route_shortened())
    {
        Packet::free(pkt);
        pkt = 0;
        return;
    }

    printf("Condition (gdsrh->route_request() || (gdsrh->route_reply()) || gdsrh->route_repaired() || gdsrh->route_shortening()) is not satisfied\n");
    
*/
    if(gdsrh->num_route_errors() >= MAX_ROUTE_ERRORS)
    {
        trace("SDFU %.5f _%s_ dumping maximally nested error %s %d -> %d",
                Scheduler::instance().clock(), net_id.dump(),
                tell_id.dump(), from_id.dump(), to_id.dump());

        Packet::free(pkt);
        pkt = 0;
        return;
    }

     printf("gdsrh->num_route_errors() = %i, Condition (gdsrh->num_route_errors() >= MAX_ROUTE_ERRORS)  is not satisfied\n", gdsrh->num_route_errors());


     if(gdsrh->route_repaired() > MAX_LOCAL_REPAIR_TIMES)
     {
         Packet::free(pkt);
         pkt = 0;
         return;
     }


     if( (!salvage) && (net_id.addr != ntable->my_label)
                      && (ntable->my_label != 255) && (!gdsrh->pass_clusterhead()))
     {
          cmh->next_hop() = ntable->my_label;
          Scheduler::instance().schedule(ll,pkt,0.0);
          return;
     }

/*
      if((salvage == 0) && (cmh->ptype() == PT_CBR) && (cmh->next_hop() == iph->daddr()))
     {
          gdsrh->route_repaired() = 6;
          GDSR_Packet pac(pkt->copy(), gdsrh);
          HDR_CMN(pac.pkt)->size() -= gdsrh->size();
         // cmh->size() = -cbrph->size();
          pac.src = net_id;
          pac.dest = ID(iph->daddr(),::IP);
          printf("repaired() = %i\n",hdr_cbrp::access(pac.pkt)->route_repaired());
         handlePktWithoutSR(pac,0);
     }
*/

    if((salvage) && (gdsrh->route_repaired() <= 5)) 
    {
       
        return;
    }
   //  if(salvage) return;







/*
      if((cmh->ptype() == PT_CBR) && (gdsrh->route_repaired() || gdsrh->route_shortened()))
    {
        Packet::free(pkt);
        return;
    }
*/

   //  gdsrh->cur_addr()--;

   link_down *deadlink = &(gdsrh->down_links()[gdsrh->num_route_errors()]);
/*    deadlink->addr_type = gdsrh->addrs[gdsrh->cur_addr()].addr_type;
    deadlink->from_addr = gdsrh->addrs[gdsrh->cur_addr()].addr;
    deadlink->to_addr = gdsrh->addrs[gdsrh->cur_addr()+1].addr;
    deadlink->tell_addr = gdsrh->addrs[0].addr;
*/
     printf("gdsrh->cur_addr() = %i, deadlink->from_addr = %i,  deadlink->to_addr = %i\n",gdsrh->cur_addr(),  deadlink->from_addr, deadlink->to_addr);
 
     if(!gdsrh->num_addrs())
     {
         Packet::free(pkt);
         pkt = 0;
         return;
     }
    if(gdsrh->addrs()[gdsrh->cur_addr()].addr != net_id.addr)
   {

    
    deadlink->addr_type = gdsrh->addrs()[gdsrh->cur_addr()].addr_type;
    deadlink->from_addr = gdsrh->addrs()[gdsrh->cur_addr()].addr;
    deadlink->to_addr = gdsrh->next_cluster();
    deadlink->tell_addr = gdsrh->addrs()[0].addr;


     if(net_id.addr != gdsrh->addrs()[gdsrh->cur_addr()+1].addr)
     {
     gdsrh->num_route_errors() += 1;
     deadlink = &(gdsrh->down_links()[gdsrh->num_route_errors()]);
     deadlink->addr_type = gdsrh->addrs()[gdsrh->cur_addr()].addr_type;
    deadlink->from_addr = net_id.addr;
    deadlink->to_addr = gdsrh->next_cluster();
    deadlink->tell_addr = gdsrh->addrs()[0].addr;
     }
     

   }
   else
   {
    deadlink->addr_type = gdsrh->addrs()[gdsrh->cur_addr()].addr_type;
    deadlink->from_addr = gdsrh->addrs()[gdsrh->cur_addr()].addr;
    deadlink->to_addr = gdsrh->next_cluster();
    deadlink->tell_addr = gdsrh->addrs()[0].addr;
   }

    gdsrh->num_route_errors() += 1;


    if(verbose_)
        trace("Sdebug %.5f _%s_ sending into dead-link (nest %d) tell %d %d -> %d", Scheduler::instance().clock(),
                net_id.dump(),gdsrh->num_route_errors(), deadlink->tell_addr, deadlink->from_addr, deadlink->to_addr);

    //collect old information
    nsaddr_t source, destination;
    source = iph->saddr();
    destination = iph->daddr();

    gdsrh->valid() = 1;
    gdsrh->route_error() = 1;
    gdsrh->route_reply() = 0;
    gdsrh->route_request() = 0;

   // iph->daddr() = deadlink->tell_addr;
    iph->daddr() = Address::instance().create_ipaddr(deadlink->tell_addr, RT_PORT);
    iph->dport() = RT_PORT;
   // iph->saddr() = net_id.addr;
    iph->saddr() = Address::instance().create_ipaddr(net_id.addr, RT_PORT);
    iph->sport() = RT_PORT;
    iph->ttl() = 255;

    cmh->ptype() = PT_GDSR;
    cmh->num_forwards() = 0;
    cmh->size() = IP_HDR_LEN;

    cmh->uid() = uidcnt_++;
   // gdsrh->num_addrs() = gdsrh->cur_addr() + 1;

    Entry *e = error_table.getEntry(ID(source,::IP));
    Time time = Scheduler::instance().clock();
    Time temp;
    if(e) temp = e->last_rt_req;
    if ((e->nextnode).addr != destination) goto send_error;
    if((BackOffTest(e,time)))
    {

     e->last_type = UNLIMIT;
     e->last_arp = time;

send_error:    GDSR_Packet p(pkt, gdsrh);
  //  p.route.setLength(p.route.index() + 1);
    p.route.setLength(gdsrh->cur_addr() +1);
    if ((ntable->my_label != 255) && (ntable->my_label != net_id.addr))
        p.route.appendToPath(ID(ntable->my_label,::IP));
    p.route.appendToPath(net_id);
    ::compressPath(p.route);
    p.route.reverseInPlace();
    p.route.resetIterator();


   // fillGDSRPath(p.route, gdsrh);

    p.dest = tell_id;
    p.src = net_id;

    cmh->prev_hop_ = net_id.addr;
    printf("Now, send out a route error, saddr() = %i, daddr() = %i, p.src.addr = %i,p.dest.addr = %i\n",iph->saddr(),iph->daddr(), p.src.addr,p.dest.addr);
     printf(" deadlink->from_addr = %i,  deadlink->to_addr = %i, deadlink->tell_addr = %i , num_route_errors() = %i\n",  deadlink->from_addr, deadlink->to_addr,deadlink->tell_addr,gdsrh->num_route_errors());

     GDSR_Agent::no_of_initiated_errors_++;
     trace("no_of_initiated_errors_ %i\n",GDSR_Agent::no_of_initiated_errors_);

     //record to send error
     error_table.insert(p.dest,p.dest,ID(destination,::IP),1);

     // if(deadlink->from_addr != deadlink->to_addr)
         sendOutPacketWithRoute(p, true);
     }


    }




void
GDSR_Agent::xmitSucceed(Packet *pkt)
{
    printf("In xmitSucceed of  node %i\n", net_id.addr);
    hdr_sr *gdsrh = hdr_sr::access(pkt);
    hdr_ip *iph = HDR_IP(pkt);
    hdr_cmn *cmh = HDR_CMN(pkt);


    printf("saddr() = %i, daddr() = %i, net_id.addr() =  %i, next_hop = %i\n",iph->saddr(),iph->daddr(),net_id.addr,cmh->next_hop());
    assert(cmh->size() >= 0);

    if(verbose_)
        trace("SSendFailure %.9f _%s_ --- %d - %s, (to %d) RREQ %d (%d, %d), RREP %d", Scheduler::instance().clock(),
                net_id.dump(), cmh->uid(),gdsrh->dump(),iph->daddr(), iph->saddr(), gdsrh->rtreq_seq(), gdsrh->route_reply());


    if(net_id.addr == cmh->next_hop())
    {
        Packet::free(pkt);
        return;
    }



            ntable_ent *nexthop = new ntable_ent();
            ntable_ent *hop = ntable->GetEntry(cmh->next_hop());

            if(hop)
            {
                nexthop->neighbor = hop->neighbor;
                nexthop->last_update = Scheduler::instance().clock();
                nexthop->neighbor_status = hop->neighbor_status;
                nexthop->neighbor_label = hop->neighbor_label;
                nexthop->next = NULL;
                ntable->AddUpdateEntry(nexthop);
            //    if((hop->neighbor_label != 255) && (hop->neighbor_label != ntable->my_label) && ntable->GetAdjEntry(hop->neighbor_label,1))
            //        ntable->AddUpdateAdj(hop->neighbor_label, hop->neighbor,hop->neighbor_label,1);
            }
           else
            {
                nexthop->neighbor = cmh->next_hop();
                nexthop->last_update = Scheduler::instance().clock();
                nexthop->neighbor_status = INITIAL_NODE;
                nexthop->neighbor_label = 255;
                nexthop->next = NULL;
                ntable->AddUpdateEntry(nexthop);
            }
         
            Packet::free(pkt);

    }



int GDSR_Agent::undeliverablePkt(Packet *pkt, int mine)
{
    hdr_sr *gdsrh = hdr_sr::access(pkt);
    hdr_ip *iph = HDR_IP(pkt);
    hdr_cmn *cmh = HDR_CMN(pkt);
    int differ = 0;

    GDSR_Packet p(pkt, gdsrh);
   // p.dest = ID(iph->daddr(), ::IP);
   // p.src = ID(iph->saddr(), ::IP);
     p.dest = ID((Address::instance().get_nodeaddr(iph->daddr())),::IP);
    p.src = ID((Address::instance().get_nodeaddr(iph->saddr())),::IP);
    p.pkt = mine ? pkt : pkt->copy();

    printf("In undeliverablePkt of node %i: saddr() = %i, daddr() = %i\n", net_id.getNSAddr_t(),iph->saddr(),iph->daddr());

    gdsrh = hdr_sr::access(p.pkt);
    iph = HDR_IP(p.pkt);
    cmh = HDR_CMN(p.pkt);


    if(p.route.member(net_id,net_id))
    {
        for (int i = 0; i < p.route.length(); i++)
        {
            if(p.route[i].addr == net_id.addr)
            {
                if((i < gdsrh->cur_addr()) && (gdsrh->cur_addr() < gdsrh->num_addrs()))
                {
                    break;
                }
                else
                {
                    gdsrh->cur_addr() = i;
                    break;
                }
            }
        }
    }
    else
    {
        for (int i = 0; i < p.route.length(); i++)
        {
            if(p.route[i].addr == ntable->my_label)
            {
                if((i < gdsrh->cur_addr()) && (gdsrh->cur_addr() < gdsrh->num_addrs()))
                {
                    break;
                }
                else
                {
                    gdsrh->cur_addr() = i;
                    break;
                }
            }
        }
    }

    Path salvage_route;
    if(gdsrh->cur_addr() >= (gdsrh->num_addrs() - 1))
    {
        trace("SDFU: route error beyond end of source route????");
    fprintf(stderr,"SDFU: route error beyond end of source route????\n");
        Packet::free(p.pkt);
        return 0;
    }

     printf("Current source route: %s\n",p.route.dump());
    printf("Before getting into salvage, p.route.index() = %i,"
            "p.route[gdsrh->cur_addr()+1].addr = %i,gdsrh->cur_addr() = %i,gdsrh->num_addrs() = %i\n",
            p.route.index(),p.route[gdsrh->cur_addr()+1].addr,gdsrh->cur_addr(),gdsrh->num_addrs());
    cmh->next_hop() = -2;
     ntable_ent *e ;
    adjtable_ent *ent;
    nexthop_ent *hop;

    //if(gdsr_local_repair && (gdsrh->route_repaired() < MAX_LOCAL_REPAIR_TIMES) && ((unsigned long)gdsrh->addrs[gdsrh->cur_addr()].addr == net_id.addr))
   if(gdsr_local_repair && (gdsrh->route_repaired() < MAX_LOCAL_REPAIR_TIMES))
    {
       

       // if((ent = ntable->GetAdjEntry(p.route[gdsrh->num_addrs() -2 ].addr,1)) && (gdsrh->cur_addr() < gdsrh->num_addrs() -3))
      if((ent = ntable->GetAdjEntry(iph->daddr(),1) ) )
        {
            printf("Find %i in adjancent table,ntable->GetAdjEntry(p.route[gdsrh->num_addrs() -2 ].addr,1) \n",p.route[gdsrh->num_addrs() -2 ].addr);

            if(ent == ntable->GetAdjEntry(iph->daddr(),1))
            {
                gdsrh->next_cluster() = iph->daddr();
            }
            goto choose_nextnode;



        }
        else if((e = ntable->GetEntry(p.route[gdsrh->cur_addr()+1].addr)) && (gdsrh->cur_addr() < gdsrh->num_addrs() -1))
        {
             printf("Find %i in neighbor table, ntable->GetEntry(p.route[gdsrh->cur_addr()+1].addr,1))\n",p.route[gdsrh->cur_addr() + 1].addr);
             gdsrh->next_cluster() = p.route[gdsrh->cur_addr()+1].addr;
             cmh->next_hop() = p.route[gdsrh->cur_addr()+1].addr;
        }
        else
      {

         differ = gdsrh->num_addrs() - 1 - gdsrh->cur_addr();
         while(differ > 1)
         {
             if ((ent = ntable->GetAdjEntry(gdsrh->addrs()[gdsrh->cur_addr() + differ].addr, 1)) && (gdsrh->num_addrs() - differ + 1))
             {
                 break;
             }
             differ--;
         }

        if((ent = ntable->GetAdjEntry(p.route[gdsrh->cur_addr() + differ].addr,1)) && ((gdsrh->cur_addr() < gdsrh->num_addrs() - differ + 1)))
        {

            if (differ > 1)
                        {
                            gdsrh->route_shortened() = 1;
                            for (int i = gdsrh->cur_addr() +1 ; i < gdsrh->num_addrs() - differ + 1; i++)
                            {
                                gdsrh->addrs()[i] = gdsrh->addrs()[i + differ -1];
                            }
                            gdsrh->num_addrs() = gdsrh->num_addrs() - differ + 1;

                        }
            gdsrh->next_cluster() = p.route[gdsrh->cur_addr()+1].addr;
            printf("Find %i in adjancent table,ntable->GetAdjEntry(p.route[gdsrh->cur_addr() + 1].addr,1) \n",p.route[gdsrh->cur_addr() + 1].addr);
choose_nextnode:            hop = ent->next_hop;
             while(hop)
             {
                // if((hop->next_node_label == en->neighbor_cluster) && (!p.route.member(ID(hop->next_node,::IP),ID(hop->next_node,::IP))))
               if((hop->next_node_label == ent->neighbor_cluster))
                 {
                     e = ntable->GetEntry(hop->next_node);
                     if(e)
                     {
                     cmh->next_hop() = hop->next_node;
                   //  gdsrh->addrs()[gdsrh->cur_addr() + 1].addr = e->neighbor_label;
                     break;
                     }
                 }
                 hop = hop->next;
             }
 /*      else if((e = ntable->GetEntry(p.route[gdsrh->cur_addr() + 2].addr)) && ((gdsrh->cur_addr() < gdsrh->num_addrs() -2)))
        {
            gdsrh->next_cluster() = p.route[gdsrh->cur_addr()+2].addr;
            printf("Find %i in ntable, ntable->GetEntry(p.route[gdsrh->cur_addr() + 2].addr)\n",p.route[gdsrh->cur_addr() + 2].addr);
           cmh->next_hop() = e->neighbor;
          // gdsrh->addrs()[gdsrh->cur_addr() + 1].addr = e->neighbor;
        //   gdsrh->addrs()[gdsrh->cur_addr() + 1].addr = e->neighbor_label;
            for(int i = gdsrh->cur_addr() + 1; i < gdsrh->num_addrs()-1; i++)
            {
                gdsrh->addrs()[i] = gdsrh->addrs()[i + 1];
            }
           gdsrh->route_shortened() = 1;
            gdsrh->num_addrs()--;




        }
        else if((ent = ntable->GetAdjEntry(p.route[gdsrh->cur_addr() + 2].addr,1)) && ((gdsrh->cur_addr() < gdsrh->num_addrs() -2)))
        {
            gdsrh->next_cluster() = p.route[gdsrh->cur_addr()+2].addr;
            printf("Find %i in adjancent table,ntable->GetAdjEntry(p.route[gdsrh->cur_addr() + 2].addr,1) \n",p.route[gdsrh->cur_addr() + 2].addr);
             for(int i = gdsrh->cur_addr() + 1; i < gdsrh->num_addrs()-1; i++)
            {
                gdsrh->addrs()[i] = gdsrh->addrs()[i + 1];
            }
            gdsrh->num_addrs()--;

            gdsrh->route_shortened() = 1;

choose_nextnode:            hop = ent->next_hop;
             while(hop)
             {
                // if((hop->next_node_label == en->neighbor_cluster) && (!p.route.member(ID(hop->next_node,::IP),ID(hop->next_node,::IP))))
               if((hop->next_node_label == ent->neighbor_cluster))
                 {
                     e = ntable->GetEntry(hop->next_node);
                     if(e)
                     {
                     cmh->next_hop() = hop->next_node;
                   //  gdsrh->addrs()[gdsrh->cur_addr() + 1].addr = e->neighbor_label;
                     break;
                     }
                 }
                 hop = hop->next;
             }
*/

            if(!hop)
            {
                hop = ent->next_hop;
                 while(hop)
             {
                // if((hop->next_node_label == ntable->my_label) && (!p.route.member(ID(hop->next_node,::IP),ID(hop->next_node,::IP))))
                if((hop->next_node_label == ntable->my_label) )
                 {
                     e = ntable->GetEntry(hop->next_node);
                     cmh->next_hop() = hop->next_node;
                   // gdsrh->addrs()[gdsrh->cur_addr() + 1].addr = e->neighbor_label;
                     break;
                 }
                 hop = hop->next;
             }
            }

            if(!hop)
            {
                cmh->next_hop() = ent->next_hop->next_node;
                e = ntable->GetEntry(ent->next_hop->next_node);
            //   gdsrh->addrs()[gdsrh->cur_addr() + 1].addr = e->neighbor_label;
            }


           // gdsrh->addrs()[gdsrh->cur_addr() + 1].addr_type = NS_AF_INET;

        }

   }

        if(cmh->next_hop() != -2)
        {
            if(gdsrh->cur_addr() == 1)
            {
                Path route;
                route.setLength(gdsrh->num_addrs());
                for (int i = 0; i < gdsrh->num_addrs(); i++)
                {
                    route[i] = ID(gdsrh->addrs()[i]);
                }
                route.resetIterator();
                route_cache->addRoute(route, Scheduler::instance().clock(),p.dest);
            }
            else
            {
                gdsrh->route_repaired()++;
            }

            for (int i = 0; i < gdsrh->num_addrs(); i++)
                {
                printf("gdsrh->addrs[%i].addr = %i\n",i,gdsrh->addrs()[i].addr);
                }

            cmh->size() += gdsrh->size();



            //add cluster-related information
            iph->node_id() = net_id.getNSAddr_t();
            iph->state() = ntable->my_status;
            iph->clusterhead[0] = ntable->my_label;
           if(ntable->adjtable_size2 <= 5)
            {
                iph->num_adj_clusters() = ntable->adjtable_size2;
            }
            else
            {
                iph->num_adj_clusters() = 5;
            }

          //  if ((iph->state() == FULL_GW || iph->state() == DIST_GW))
            if(iph->num_adj_clusters())
            {
                adjtable_ent *e = ntable->adjtable_2;
                for (int i = 1; i <= ntable->adjtable_size2; i++)
                {
                    if(i <=5)
                    {
                        while(e)
                        {
                            iph->clusterhead[i] = e->neighbor_cluster;
                            e = e->next;
                            break;
                        }
                    }
                    else
                    {
                        break;
                    }
                }

            }
            cmh->prev_hop_ = net_id.getNSAddr_t();





            cmh->size() +=gdsrh->size();

            Scheduler::instance().schedule(ll,p.pkt,0);
            p.pkt = NULL;
            return 1;
        }

    }


 //  if(gdsr_salvage_with_cache && (gdsrh->route_repaired() < MAX_LOCAL_REPAIR_TIMES)
//            && ((route_cache->findRoute(p.dest, salvage_route, 0) || (route_cache->findRoute(p.dest,salvage_route,1)))))
    if(gdsr_salvage_with_cache && (gdsrh->route_repaired() < MAX_LOCAL_REPAIR_TIMES)
            && (route_cache->findRoute(p.dest, salvage_route, 0)))
    {
       printf("gdsr_salvage_with_cache\n");
        p.route = salvage_route;
        p.route.resetIterator();
      //  fillGDSRPath(p.route, gdsrh);
        p.route.fillSR(gdsrh);
     //   cmh->next_hop() = gdsrh->addrs()[gdsrh->cur_addr()].addr;
        printf("gdsrh->cur_addr() = %i, gdsrh->addrs()[gdsrh->cur_addr()].addr = %i\n",gdsrh->cur_addr(),gdsrh->addrs()[gdsrh->cur_addr()].addr);
        for (int k = 0; k < p.route.length(); k++)
       {
          printf("p.route[%i].addr = %i\n",k, p.route[k].getNSAddr_t());
       }

        
         if((ent = ntable->GetAdjEntry(iph->daddr(),1) ) )
        {
           
           


            if(ent == ntable->GetAdjEntry(iph->daddr(),1))
            {
                gdsrh->next_cluster() = iph->daddr();
            }
            goto nextnode;



        }
        else if((e = ntable->GetEntry(p.route[gdsrh->cur_addr() + 1].addr)) && (gdsrh->cur_addr() < gdsrh->num_addrs()))
        {
             printf("Find %i in neighbor table, ntable->GetEntry(p.route[gdsrh->cur_addr() + 1].addr,1))\n",p.route[gdsrh->cur_addr() + 1].addr);
             gdsrh->next_cluster() = p.route[gdsrh->cur_addr() + 1].addr;
             cmh->next_hop() = p.route[gdsrh->cur_addr() + 1].addr;
        }
        else
         {

              differ = gdsrh->num_addrs() - 1 - gdsrh->cur_addr();
         while(differ > 1)
         {
             if ((ent = ntable->GetAdjEntry(gdsrh->addrs()[gdsrh->cur_addr() + differ].addr, 1)) && (gdsrh->cur_addr() < gdsrh->num_addrs() - differ + 1))
             {
                 break;
             }
             differ--;
         }

       if((ent = ntable->GetAdjEntry(p.route[gdsrh->cur_addr() + differ].addr,1)) && ((gdsrh->cur_addr() < gdsrh->num_addrs() - differ + 1)))
        {
           if (differ > 1)
           {
              gdsrh->route_shortened() = 1;
              for (int i = gdsrh->cur_addr() +1 ; i < gdsrh->num_addrs() - differ + 1; i++)
              {
                 gdsrh->addrs()[i] = gdsrh->addrs()[i + differ -1];
              }
              gdsrh->num_addrs() = gdsrh->num_addrs() - differ + 1;
           }
            gdsrh->next_cluster() = p.route[gdsrh->cur_addr() + 1].addr;
            printf("Find %i in adjancent table,ntable->GetAdjEntry(p.route[gdsrh->cur_addr() + 1].addr,1) \n",p.route[gdsrh->cur_addr() + 1].addr);
nextnode:            hop = ent->next_hop;
             while(hop)
             {
                // if((hop->next_node_label == en->neighbor_cluster) && (!p.route.member(ID(hop->next_node,::IP),ID(hop->next_node,::IP))))
               if((hop->next_node_label == ent->neighbor_cluster))
                 {
                     e = ntable->GetEntry(hop->next_node);
                     if(e)
                     {
                     cmh->next_hop() = hop->next_node;
                   //  gdsrh->addrs()[gdsrh->cur_addr() + 1].addr = e->neighbor_label;
                     break;
                     }
                 }
                 hop = hop->next;
             }

            if(!hop)
            {
                hop = ent->next_hop;
                 while(hop)
             {
                // if((hop->next_node_label == ntable->my_label) && (!p.route.member(ID(hop->next_node,::IP),ID(hop->next_node,::IP))))
                if((hop->next_node_label == ntable->my_label) )
                 {
                     e = ntable->GetEntry(hop->next_node);
                     cmh->next_hop() = hop->next_node;
                   // gdsrh->addrs()[gdsrh->cur_addr() + 1].addr = e->neighbor_label;
                     break;
                 }
                 hop = hop->next;
             }
            }

            if(!hop)
            {
                cmh->next_hop() = ent->next_hop->next_node;
                e = ntable->GetEntry(ent->next_hop->next_node);
            
            }
        }
   }

          trace("GDSR %.5f _%s_ salvage-cache %s -> %s --- %d with %s",
                Scheduler::instance().clock(), net_id.dump(),
                p.src.dump(), p.dest.dump(), cmh->uid(), p.route.dump());

          if(cmh->next_hop() != -2)
          {
               gdsrh->route_repaired() = MAX_LOCAL_REPAIR_TIMES + 1;
        cmh->size() +=gdsrh->size();
      //  cmh->size() = IP_HDR_LEN + gdsrh->size();
        p.route.setLength(gdsrh->num_addrs());



         //add cluster-related information
            iph->node_id() = net_id.getNSAddr_t();
            iph->state() = ntable->my_status;
            iph->clusterhead[0] = ntable->my_label;
            if(ntable->adjtable_size2 <= 5)
            {
                iph->num_adj_clusters() = ntable->adjtable_size2;
            }
            else
            {
                iph->num_adj_clusters() = 5;
            }
          //  if ((iph->state() == FULL_GW || iph->state() == DIST_GW))
            if(iph->num_adj_clusters())
            {
                adjtable_ent *e = ntable->adjtable_2;
                for (int i = 1; i <= ntable->adjtable_size2; i++)
                {
                    if (i <= 5)
                    {
                        while(e)
                        {
                            iph->clusterhead[i] = e->neighbor_cluster;
                            e = e->next;
                            break;
                        }
                    }
                    else
                    {
                        break;
                    }
                }

            }
            cmh->prev_hop_ = net_id.getNSAddr_t();






            printf("Packet will be sent to %i\n", HDR_CMN(p.pkt)->next_hop());
        Scheduler::instance().schedule(ll, p.pkt, 0);
        p.pkt = NULL;
      //  Scheduler::instance().schedule(ll, p.pkt, Random::uniform(0.01));
        return 1;
          }
    }



    if(ID(iph->saddr(), ::IP) == net_id)
    {
        printf("now goto handlepktwithoutsr\n");
  
         trace("gdsr SAVVVE by re-handle it %d -> %d old src route %s",iph->saddr(),iph->daddr(),p
.route.dump());

        gdsrh->init();
        handlePktWithoutSR(p, false);
        return 0;
    }

    trace("Ssalv %.5f _%s_ dropping --- %d %s -> %s %s CBR %d",
          Scheduler::instance().clock(),
          net_id.dump(), cmh->uid(), p.src.dump(), p.dest.dump(), p.route.dump(), gdsrh->valid());

    if(mine) drop(pkt, DROP_RTR_NO_ROUTE);
    return 0;
}










void GDSR_Agent::processBrokenRouteError(GDSR_Packet &p)
{

    hdr_sr *gdsrh = hdr_sr::access(p.pkt);
    hdr_ip *iph = HDR_IP(p.pkt);

    printf("In processBrokenRouteError of node %i: saddr() = %i, daddr() = %i, prev_hop() = %i\n",net_id.addr,iph->saddr(),iph->daddr(),HDR_CMN(p.pkt)->prev_hop_);
    printf("gdsrh->route_request() = %i, gdsrh->route_reply() = %i, gdsrh->route_error() = %i, gdsrh->num_route_errors() = %i\n",gdsrh->route_request(),gdsrh->route_reply(), gdsrh->route_error(),gdsrh->num_route_errors());

    if(!gdsrh->route_error()) return;
    assert(gdsrh->num_route_errors() >0);
   int count = gdsrh->num_route_errors();
    for(int c= 0; c< count; c++)
    {
        assert(gdsrh->down_links()[c].addr_type == NS_AF_INET);
        printf("Now notice DeadLink in routecache:c = %i,gdsrh->down_links()[%i].from_addr = %i, gdsrh->downlinks[%i].to_addr = %i\n",c,c,gdsrh->down_links()[c].from_addr,c,gdsrh->down_links()[c].to_addr);



       // if(gdsrh->down_links()[c].from_addr != gdsrh->down_links()[c].to_addr)
        route_cache->noticeDeadLink(ID(gdsrh->down_links()[c].from_addr, ::IP), ID(gdsrh->down_links()[c].to_addr, ::IP), Scheduler::instance().clock());
if((ntable->GetAdjEntry(gdsrh->down_links()[c].to_addr,1) || (ntable->GetAdjEntry(gdsrh->down_links()[c].to_addr,0))) && ntable->GetEntry(gdsrh->down_links()[c].from_addr))
{
    ntable->DeleteNextnodeToNextCluster(gdsrh->down_links()[c].to_addr,gdsrh->down_links()[c].from_addr,1);
    ntable->DeleteNextnodeToNextCluster(gdsrh->down_links()[c].to_addr,gdsrh->down_links()[c].from_addr,0);

}
        

         if (verbose_srr)
        trace("SRR %.9f _%s_ dead-link tell %d  %d -> %d",
              Scheduler::instance().clock(), net_id.dump(),
              gdsrh->down_links()[c].tell_addr,
              gdsrh->down_links()[c].from_addr,
              gdsrh->down_links()[c].to_addr);

    }




      ID who = ID(gdsrh->down_links()[gdsrh->num_route_errors()-1].tell_addr, ::IP);
      if((who != net_id) && (who != MAC_id))
      {
          return;
      }

      route_error_held = true;
      err_from = ID(gdsrh->down_links()[gdsrh->num_route_errors() - 1].from_addr, ::IP);
      err_to = ID(gdsrh->down_links()[gdsrh->num_route_errors() - 1].to_addr, ::IP);
      route_error_data_time = Scheduler::instance().clock();



      if( 1 == gdsrh->num_route_errors())
      {
          return;
      }





     if (verbose_)
    trace("Sdebug %.5f _%s_ unwrapping nested route error",
          Scheduler::instance().clock(), net_id.dump());


      GDSR_Packet p_copy = p;
      p_copy.pkt = p.pkt->copy();
      hdr_sr *new_gdsrh = hdr_sr::access(p_copy.pkt);
      hdr_ip *new_iph = HDR_IP(p_copy.pkt);

      new_gdsrh->num_route_errors() -= 1;
    //  new_gdsrh->route_request() = 0;


      p_copy.dest = ID(new_gdsrh->down_links()[new_gdsrh->num_route_errors() - 1].tell_addr, ::IP);
      p_copy.src = net_id;

      //new_iph->daddr() = p_copy.dest.addr;
      new_iph->daddr() = Address::instance().create_ipaddr(p_copy.dest.getNSAddr_t(), RT_PORT);
      new_iph->dport() = RT_PORT;
     // new_iph->saddr() = p_copy.src.addr;
      new_iph->saddr() = Address::instance().create_ipaddr(p_copy.src.getNSAddr_t(),RT_PORT);
      new_iph->sport() = RT_PORT;
      new_iph->ttl() = 255;



      handlePktWithoutSR(p_copy, false);

}


void GDSR_Agent::trace(char *fmt, ...)
{
    va_list ap;

    if(!logtarget) return;

    va_start(ap, fmt);
    vsprintf(logtarget->pt_->buffer(), fmt, ap);
    logtarget->pt_->dump();
    va_end(ap);


}
