/* 
 * File:   gdsr_pkt.h
 * Author: root
 *
 * Created on January 14, 2011, 10:22 PM
 */

#ifndef GDSR_PKT_H
#define	GDSR_PKT_H


#include <packet.h>
#include "dsr/path.h"
#include "dsr/hdr_sr.h"


struct GDSR_Packet {

 // nsaddr_t label;// I Add  2 lines to support cluster label for CLUSTER_Packet
 // uint status;
  ID dest;
  ID src;
  Packet *pkt;   /* the inner NS packet */
  Path route;
  GDSR_Packet(Packet *p, struct hdr_sr *srh) : pkt(p), route(srh) {}
  GDSR_Packet() : pkt(NULL) {}

};




#endif	/* GDSR_PKT_H */

