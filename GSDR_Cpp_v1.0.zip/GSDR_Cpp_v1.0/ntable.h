/* 
 * File:   GDSR_ntable.h
 * Author: root
 *
 * Created on January 25, 2011, 2:25 PM
 */

#ifndef GDSR_NTABLE_H
#define	GDSR_NTABLE_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#include "config.h"
#include "packet.h"
#include "scheduler.h"
#include "queue.h"
#include "gdsragent.h"

#define MAX_NODE_NUM 150

#define INITIAL_NODE 1
#define ORDINARY_NODE 2
#define CLUSTER_HEAD 3
#define FULL_GW 4
#define DIST_GW 5
#define CH_READY 6
#define GW_READY 7
#define GATEWAY 8

#define GDSR_STARTUP_JITTER 0.1
//#define GDSR_BROADCAST_INTERVAL 2.0
//#define GDSR_BROADCAST_INTERVAL 3.0
#define GDSR_BROADCAST_INTERVAL 5
#define TIMEOUT_INTERVAL 3.0
#define GDSR_BROADCAST_JITTER 0.15

typedef unsigned int uint;

class GDSRNeighborTableTimeoutHandler;
class GDSRNeighborTableContentionHandler;
class GDSRNeighborTablePeriodicHandler;
class GDSR_Agent;

class ntable_ent {
public:
    ntable_ent() { bzero (this, sizeof(struct ntable_ent));}
    nsaddr_t neighbor;
    uint neighbor_status;
    nsaddr_t neighbor_label;
    double last_update;
    Event * timeout_event;
    ntable_ent *next;
};


class nexthop_ent {
public:
    nexthop_ent() {bzero(this, sizeof(struct nexthop_ent));}
    nsaddr_t next_node;
   // uint next_node_status;
    nsaddr_t next_node_label;
    Event* timeout_event;
    nexthop_ent *next;

};

class adjtable_ent {
public:
    adjtable_ent() { bzero(this, sizeof(struct adjtable_ent));}
    nsaddr_t neighbor_cluster;
    nexthop_ent *next_hop;
    adjtable_ent *next;

};

class GDSRNeighborTable {
    friend class GDSRNeighbortableTimeoutHandler;
    friend class GDSRNeighborTableContentionHandler;
    friend class GDSRNeighborTablePeriodicHandler;
    friend class GDSR_Agent;

public:
    GDSRNeighborTable(GDSR_Agent *a_);

    void AddUpdateEntry(ntable_ent *ent);
    ntable_ent *GetEntry(nsaddr_t dest);
    int DeleteEntry(nsaddr_t dest);

    void InitLoop();
    ntable_ent *NextLoop();

    void AddUpdateAdj(nsaddr_t dest, nsaddr_t next_hop, int primary);
    void AddUpdateAdj(nsaddr_t dest, nsaddr_t next_hop, nsaddr_t label, int primary);
    void DeleteAdjEntry(nsaddr_t dest, int primary);
    adjtable_ent *GetAdjEntry(nsaddr_t dest_cluster, int primary);
    void DeleteNeighborCluster(nsaddr_t dest, int primary);
    

    void DeleteNextnodeToNextCluster(nsaddr_t dest, nsaddr_t nextnode, int primary);

    void processUpdate(Packet *);

    Packet* sendGiveUpPacket();
    Packet *sendUnicastCluster();
    bool isNeighbor(nsaddr_t addr);

    void reCalculateMemberState();
    void changeMemberState();
    void changeMemberState(Packet *p);

    void startUp();




    //my 2 clusterhead
    nsaddr_t ch1;
    nsaddr_t ch2;

    uint internal_status;
    uint external_status;
    uint last_status;
    uint my_status;

    nsaddr_t my_label;
    nsaddr_t my_rival;
    nsaddr_t last_label;

    uint no_of_clusterheads;
    uint no_of_gateways;
    uint no_of_ordinaries;
    uint no_of_initials;

    uint adjtable_size;
    uint adjtable_size1;
    uint last_size1;
    uint adjtable_size2;

    Event *c_contention_event;
    Event *periodic_event;


    GDSRNeighborTableTimeoutHandler *timeout_handler;
    GDSRNeighborTableContentionHandler *c_contention_handler;
    GDSRNeighborTablePeriodicHandler *periodic_handler;


    adjtable_ent *adjtable_1;
    adjtable_ent *adjtable_2;

protected:
    void lostClusterheads();
    

private:
    GDSR_Agent *a;
    ntable_ent *head;
    ntable_ent *prev;
    ntable_ent *now;

    
   

   int in_contention;


};


class GDSRNeighborTableTimeoutHandler : public Handler {
public:
    GDSRNeighborTableTimeoutHandler(GDSR_Agent *a_, GDSRNeighborTable *t_);
    virtual void handle (Event *e);
    int checkAdjTimeout(Event *e, int primary);
private:
    GDSRNeighborTable *t;
    GDSR_Agent *a;

};

class GDSRNeighborTableContentionHandler : public Handler {
public:
    GDSRNeighborTableContentionHandler(GDSR_Agent *a_, GDSRNeighborTable *t_);
    virtual void handle(Event *e);

private:
    GDSRNeighborTable *t;
    GDSR_Agent *a;
};



class GDSRNeighborTablePeriodicHandler : public Handler {
public:
    GDSRNeighborTablePeriodicHandler(GDSR_Agent *a_,GDSRNeighborTable *t_);
    virtual void handle(Event *e);
private:
    GDSRNeighborTable *t;
    GDSR_Agent *a;
    Event *periodic_event_;

};

#endif	/* GDSR_NTABLE_H */

